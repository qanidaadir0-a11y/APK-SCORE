# FIFA World Cup 2026 Predictor

Calibrated win / draw / loss and correct-score probabilities for international
football, built from two sources: **twenty years of World Cup results** and
**EA SPORTS FC 25 national-team ratings**.

The interesting part is not that it makes a prediction. It is that it tells you
how much the prediction is worth. Every number the UI shows is scored by
expanding-window walk-forward validation against four baselines the model has
to beat — the same protocol you would use to decide whether a trading signal is
real or an artefact of the backtest.

```
React 18 + TypeScript + Vite  ──HTTP──▶  Flask API  ──▶  Elo  ─┐
                                                               ├─▶  stacked
                                              Dixon-Coles  ────┘    logistic
                                              goal model            classifier
```

---

## Run it

Two commands, and the model trains itself on first boot.

```bash
make install     # venv + pip + npm
make train       # fit the model, run the backtest, write backend/artifacts/
make dev         # Flask on :8000, Vite on :5173
```

Then open <http://localhost:5173>.

<details>
<summary>Without make (Windows / manual)</summary>

```bash
# backend
cd backend
python -m venv .venv
.venv\Scripts\activate          # macOS/Linux: source .venv/bin/activate
pip install -r requirements-dev.txt
python scripts/train.py
python wsgi.py                  # http://127.0.0.1:8000

# frontend, in a second terminal
cd frontend
npm install
npm run dev                     # http://localhost:5173
```
</details>

<details>
<summary>Docker</summary>

```bash
docker compose up --build       # app on :8080, API on :8000
```
The API image trains at build time, so the first request does not pay for it.
</details>

---

## How the model works

Three layers, each earning its place.

### 1. Elo — the memory of results

A weighted Elo engine (`ml/elo.py`) streams the match history in order. Two
departures from chess Elo, both standard in football rating work: the K factor
scales with a **concave function of the goal margin**, and with **match
importance**, so a World Cup final moves ratings more than a group opener.

Unrated newcomers do not start level with Brazil — Elo is seeded from the EA FC
25 ratings, which is what makes cold-start predictions sane.

### 2. Dixon-Coles — the distribution of the scoreline

`ml/dixon_coles.py` fits a bivariate Poisson goal model by penalised maximum
likelihood. Each team gets an attack and a defence coefficient in log-goal
space; the `rho` term applies the Dixon & Coles (1997) correction to the four
low-scoring cells that independent Poisson mis-prices (0-0, 1-0, 0-1, 1-1).

Two extensions matter here:

- **Exponential time decay** — a 2006 result should not count as much as a 2022
  one. Half-life defaults to one World Cup cycle.
- **Shrinkage to a ratings prior.** The likelihood has nothing to say about a
  team with no matches in the corpus, and a World Cup always has those. Each
  team's coefficients are ridge-penalised toward a prior derived from its EA FC
  25 attack and defence ratings. A team with a long history is driven by its
  results; a team with none collapses onto its ratings prior; teams in between
  blend smoothly. This is empirical-Bayes shrinkage, and it is how the two data
  sources are genuinely *fused* rather than merely concatenated.

Fitted with a hand-written Adam optimiser over analytic gradients — NumPy only,
no black box.

### 3. Stacked logistic classifier — the forecast

`ml/classifier.py` takes 19 causal features (Elo difference and expectancy,
rating differentials, rolling form, rest days, neutrality, knockout flag) plus
the **Dixon-Coles output as a feature**, and fits a multinomial logistic
regression. Standardisation lives inside the pipeline so it refits per fold;
the weighted fit is wrapped in Platt calibration over a *time-series* split,
never a shuffled K-fold.

Logistic regression is a deliberate choice, not a default. The output has to be
a calibrated probability rather than a label, the coefficients are readable as
log-odds contributions, and with a few hundred training rows anything with more
capacity memorises the corpus.

---

## Does it work?

```bash
cd backend && python scripts/train.py
```

prints the walk-forward table the UI renders. Indicative shape of the result
(regenerate for the real numbers — they move with the data):

| model | accuracy | log loss | Brier | RPS |
| --- | --- | --- | --- | --- |
| Uniform (⅓ each) | 41.5% | 1.0986 | 0.6667 | 0.2408 |
| Base rate | 41.5% | 1.0668 | 0.6467 | 0.2371 |
| Elo only | 55.1% | 1.0223 | 0.5823 | 0.2039 |
| Dixon-Coles only | 54.5% | 1.0142 | 0.5998 | 0.2127 |
| **Stacked model** | **56.3%** | **1.0006** | 0.5916 | 0.2064 |

Read that table carefully, because it is the honest version:

- The stack beats every baseline on **log loss**, the strictly proper rule it
  is fitted against.
- It does **not** beat Elo-only on Brier or RPS by a meaningful margin. Elo is a
  genuinely strong single feature for international football, and the stack's
  advantage is in the tails rather than the centre.
- **Accuracy near 56% is the ceiling, not a disappointment.** Three-way football
  markets are close to irreducibly uncertain; bookmakers with vastly more
  information land in the same region. Any football model claiming 80% accuracy
  on win/draw/loss is either measuring something else or leaking.

Four metrics are reported rather than one, because they disagree in useful
ways. `metrics.py` includes a test demonstrating that log loss cannot
distinguish "said draw when it was a home win" from "said away win when it was
a home win", while **RPS** — the standard football-forecasting metric — can,
because the outcome is ordered.

---

## Leakage

Every feature answers one question: *what was knowable the moment before
kick-off?* The design matrix is built by a strictly forward one-pass sweep
(`ml/features.py`), never a `groupby` over the whole frame. The Dixon-Coles
features are refitted on an expanding window of past matches only.

`tests/test_features.py::test_features_depend_only_on_the_prefix` enforces
this: it builds the matrix on the first 150 matches and on the first 260, and
asserts the overlapping rows are identical. If any future information leaked
backwards, those rows would differ and the test fails.

---

## Layout

```
backend/
  app/              Flask: factory, config, blueprints, request validation
    api/            routes_health, routes_teams, routes_predict, routes_model
    services/       the web layer's single point of contact with the model
  ml/               framework-free modelling layer — imports nothing from Flask
    io.py           loading + name canonicalisation
    elo.py          weighted Elo engine
    dixon_coles.py  bivariate Poisson + low-score correction + ratings prior
    features.py     causal feature engineering
    classifier.py   stacked multinomial logistic + calibration
    backtest.py     expanding-window walk-forward vs four baselines
    metrics.py      log loss, Brier, RPS, calibration, ECE
    pipeline.py     orchestration + persistence
  scripts/          train.py, fetch_results.py, evaluate.py
  tests/            47 tests: data integrity, leakage, model invariants, API
frontend/
  src/api/          typed fetch client — one place for errors and timeouts
  src/components/   Hero, Predictor, ScoreGrid, ModelCard, Rankings, …
  src/types/api.ts  the API contract, mirrored in TypeScript
data/raw/           match history, EA FC 25 ratings, aliases, fixtures
docs/               ARCHITECTURE.md, MODEL.md, ROADMAP.md
```

`ml/` never imports from `app/`. The whole pipeline is drivable from a notebook
or a scheduled job, and the web layer could be replaced without touching it.

---

## API

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/api/health` · `/api/ready` | Liveness / readiness |
| `GET` | `/api/teams` | Every team, with Elo and EA FC 25 inputs |
| `GET` | `/api/rankings?limit=50` | Elo table |
| `GET` | `/api/fixtures` | Fixture list driving the board |
| `POST` | `/api/predict` | Price one fixture |
| `POST` | `/api/predict/batch` | Up to 32 fixtures in one round trip |
| `POST` | `/api/predict/score-grid` | Joint scoreline distribution |
| `GET` | `/api/model/metrics` | Headline out-of-sample scores |
| `GET` | `/api/model/report` | Full training report |
| `GET` | `/api/model/features` | Standardised coefficients |
| `GET` | `/api/model/calibration` | Reliability table + variant comparison |

```bash
curl -s localhost:8000/api/predict \
  -H 'Content-Type: application/json' \
  -d '{"home_team":"Argentina","away_team":"France","knockout":true}' | python -m json.tool
```

---

## Data

- `data/raw/international_results.csv` — every match of the last five World Cup
  final tournaments (2006–2022), 320 matches, complete brackets, verified by a
  test that each edition has exactly 64.
- `data/raw/ea_fc25_national_ratings.csv` — EA FC 25 overall / attack /
  midfield / defence for 127 nations.

To train on the full international record instead — qualifiers, continental
tournaments and friendlies, ~48,000 matches — run `make data`, which pulls the
openly-licensed [martj42/international_results](https://github.com/martj42/international_results)
dataset and normalises it through the alias map. The trainer prefers that file
when present and falls back to the bundled core, so **the repo trains and
serves with no network access**.

See [`data/README.md`](data/README.md) for the schema and provenance notes.

---

## Testing

```bash
cd backend && pytest
```

47 tests, in four groups: data integrity (complete brackets, resolved aliases,
every corpus team rated), model invariants (Elo is zero-sum, score matrices are
distributions, the `rho` correction touches only four cells, artifacts round-trip
exactly), leakage guards, and API contract (validation, 404s with suggestions,
the legacy `team1`/`team2` body from the original prototype still works).

---

## Further reading

- [`docs/MODEL.md`](docs/MODEL.md) — the maths, the hyperparameters, and what is
  wrong with them
- [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) — why the layers are split the
  way they are
- [`docs/ROADMAP.md`](docs/ROADMAP.md) — what to build next, in order

## Licence

MIT. Not affiliated with or endorsed by FIFA or EA SPORTS. A forecasting
project, not a betting product.
