"""Flask application factory.

The factory pattern is here for a reason beyond tidiness: the test suite builds
a fresh app per test with an isolated config, and the same code path serves
`flask run`, gunicorn and the container image.
"""
from __future__ import annotations

import logging

from flask import Flask, jsonify
from flask_cors import CORS

from app.api import api
from app.config import Config, get_config
from app.errors import register_error_handlers
from app.services.prediction_service import PredictionService


def create_app(config: Config | None = None) -> Flask:
    config = config or get_config()
    app = Flask(__name__)
    app.config.from_object(config)
    app.config["ENV"] = config.ENV

    logging.basicConfig(
        level=logging.DEBUG if config.DEBUG else logging.INFO,
        format="%(asctime)s %(levelname)-8s %(name)s | %(message)s",
    )

    CORS(app, resources={r"/api/*": {"origins": config.CORS_ORIGINS}})

    app.extensions["prediction_service"] = PredictionService(
        model_path=config.MODEL_PATH,
        train_on_startup=config.TRAIN_ON_STARTUP,
    )

    app.register_blueprint(api)
    register_error_handlers(app)

    @app.get("/")
    def index():
        return jsonify({
            "service": "FIFA World Cup 2026 Predictor API",
            "docs": "/api/health",
            "endpoints": sorted(
                str(rule) for rule in app.url_map.iter_rules()
                if str(rule).startswith("/api")
            ),
        })

    return app
