from flask import Blueprint

from app.api import routes_health, routes_model, routes_predict, routes_teams

api = Blueprint("api", __name__, url_prefix="/api")
api.register_blueprint(routes_health.bp)
api.register_blueprint(routes_teams.bp)
api.register_blueprint(routes_predict.bp)
api.register_blueprint(routes_model.bp)

__all__ = ["api"]
