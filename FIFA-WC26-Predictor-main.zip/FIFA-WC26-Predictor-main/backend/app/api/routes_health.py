from __future__ import annotations

import time

from flask import Blueprint, current_app, jsonify

bp = Blueprint("health", __name__)
_BOOTED_AT = time.time()


@bp.get("/health")
def health():
    """Liveness only — deliberately does not touch the model."""
    return jsonify({
        "status": "ok",
        "service": "fifa-wc26-predictor",
        "environment": current_app.config.get("ENV", "development"),
        "uptime_seconds": round(time.time() - _BOOTED_AT, 1),
    })


@bp.get("/ready")
def ready():
    """Readiness — the model must be loaded and able to answer."""
    service = current_app.extensions["prediction_service"]
    pipeline = service.ensure_ready()
    return jsonify({
        "status": "ready",
        "model_trained_at": pipeline.report.trained_at if pipeline.report else None,
        "teams": len(pipeline.state.dixon_coles.teams),
    })
