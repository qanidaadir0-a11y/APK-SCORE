from __future__ import annotations

from flask import Blueprint, current_app, jsonify

bp = Blueprint("model", __name__)


def _service():
    return current_app.extensions["prediction_service"]


@bp.get("/model/report")
def report():
    """The full training report: backtest, baselines, calibration, coefficients."""
    return jsonify(_service().report())


@bp.get("/model/metrics")
def metrics():
    """Just the headline out-of-sample numbers — what the UI puts on screen."""
    full = _service().report()
    backtest = full.get("backtest") or {}
    pooled = backtest.get("pooled_out_of_sample", {})
    return jsonify({
        "trained_at": full.get("trained_at"),
        "n_matches": full.get("n_matches"),
        "n_training_rows": full.get("n_training_rows"),
        "n_teams": full.get("n_teams"),
        "date_range": full.get("date_range"),
        "out_of_sample": pooled,
        "n_out_of_sample": backtest.get("n_out_of_sample"),
        "skill_vs_uniform": backtest.get("skill_vs_uniform"),
        "dixon_coles": full.get("dixon_coles"),
    })


@bp.get("/model/features")
def features():
    """Standardised logistic coefficients, largest absolute effect first."""
    return jsonify({"features": _service().report().get("feature_importance", [])})


@bp.get("/model/calibration")
def calibration():
    backtest = _service().report().get("backtest") or {}
    return jsonify({"calibration": backtest.get("calibration", []),
                    "variants": backtest.get("variants", [])})
