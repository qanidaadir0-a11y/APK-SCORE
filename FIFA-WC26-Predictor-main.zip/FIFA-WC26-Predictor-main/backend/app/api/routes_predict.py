from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request

from app.api.schemas import PredictRequest, parse_batch

bp = Blueprint("predict", __name__)


def _service():
    return current_app.extensions["prediction_service"]


@bp.post("/predict")
def predict():
    """Price a single fixture.

    Body: ``{"home_team": "...", "away_team": "...", "neutral": true, "knockout": false}``
    """
    req = PredictRequest.parse(request.get_json(silent=True))
    return jsonify(_service().predict(req.home_team, req.away_team,
                                      neutral=req.neutral, knockout=req.knockout))


@bp.post("/predict/batch")
def predict_batch():
    """Price up to 32 fixtures in one round trip (used by the fixtures board)."""
    service = _service()
    results = []
    for req in parse_batch(request.get_json(silent=True)):
        results.append(service.predict(req.home_team, req.away_team,
                                       neutral=req.neutral, knockout=req.knockout))
    return jsonify({"count": len(results), "predictions": results})


@bp.post("/predict/score-grid")
def score_grid():
    """The full joint scoreline distribution, for the heat-map view."""
    req = PredictRequest.parse(request.get_json(silent=True))
    return jsonify(_service().score_grid(req.home_team, req.away_team, neutral=req.neutral))
