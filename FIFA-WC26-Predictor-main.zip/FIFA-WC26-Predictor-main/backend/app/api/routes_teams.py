from __future__ import annotations

from flask import Blueprint, current_app, jsonify, request

bp = Blueprint("teams", __name__)


def _service():
    return current_app.extensions["prediction_service"]


@bp.get("/teams")
def list_teams():
    """Every team the model can price, with its Elo and EA FC 25 inputs."""
    teams = _service().teams()

    confederation = request.args.get("confederation")
    if confederation:
        teams = [t for t in teams if t["confederation"].casefold() == confederation.casefold()]

    query = request.args.get("q")
    if query:
        q = query.casefold()
        teams = [t for t in teams if q in t["name"].casefold()]

    rated_only = request.args.get("rated_only", "false").lower() in {"1", "true", "yes"}
    if rated_only:
        teams = [t for t in teams if t["rated"]]

    return jsonify({"count": len(teams), "teams": teams})


@bp.get("/teams/<path:name>")
def team_detail(name: str):
    service = _service()
    resolved = service.resolve_team(name)
    team = next(t for t in service.teams() if t["name"] == resolved)
    return jsonify(team)


@bp.get("/rankings")
def rankings():
    limit = min(int(request.args.get("limit", 50)), 250)
    return jsonify({"rankings": _service().elo_table(limit)})


@bp.get("/fixtures")
def fixtures():
    return jsonify({"fixtures": _service().fixtures()})
