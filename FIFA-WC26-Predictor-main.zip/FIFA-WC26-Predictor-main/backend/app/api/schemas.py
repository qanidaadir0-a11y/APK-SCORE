"""Hand-rolled request validation.

Small enough not to need a validation library, strict enough that no unchecked
value reaches the model: unknown teams, self-matches and out-of-range integers
are all rejected at the edge with a 400 rather than surfacing as a 500.
"""
from __future__ import annotations

from dataclasses import dataclass

from app.errors import ApiError

MAX_BATCH = 32


def _require_str(payload: dict, key: str) -> str:
    value = payload.get(key)
    if not isinstance(value, str) or not value.strip():
        raise ApiError(f"`{key}` is required and must be a non-empty string",
                       details={"field": key})
    return value.strip()


def _optional_bool(payload: dict, key: str, default: bool) -> bool:
    value = payload.get(key, default)
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.lower() in {"1", "true", "yes"}
    raise ApiError(f"`{key}` must be a boolean", details={"field": key})


@dataclass(frozen=True)
class PredictRequest:
    home_team: str
    away_team: str
    neutral: bool
    knockout: bool

    @classmethod
    def parse(cls, payload: dict | None) -> "PredictRequest":
        if not isinstance(payload, dict):
            raise ApiError("Request body must be a JSON object")
        # accept the legacy team1/team2 names from the original prototype
        body = dict(payload)
        body.setdefault("home_team", body.get("team1", ""))
        body.setdefault("away_team", body.get("team2", ""))

        home = _require_str(body, "home_team")
        away = _require_str(body, "away_team")
        if home.casefold() == away.casefold():
            raise ApiError("A team cannot play itself",
                           details={"home_team": home, "away_team": away})
        return cls(home, away,
                   _optional_bool(body, "neutral", True),
                   _optional_bool(body, "knockout", False))


def parse_batch(payload: dict | None) -> list[PredictRequest]:
    if not isinstance(payload, dict) or not isinstance(payload.get("fixtures"), list):
        raise ApiError("Request body must be `{\"fixtures\": [...]}`")
    fixtures = payload["fixtures"]
    if not fixtures:
        raise ApiError("`fixtures` must contain at least one fixture")
    if len(fixtures) > MAX_BATCH:
        raise ApiError(f"At most {MAX_BATCH} fixtures per request",
                       details={"received": len(fixtures), "max": MAX_BATCH})
    return [PredictRequest.parse(f) for f in fixtures]
