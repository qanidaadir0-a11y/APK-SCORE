"""Configuration, resolved from the environment with sane local defaults."""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

BACKEND_DIR = Path(__file__).resolve().parents[1]
REPO_ROOT = BACKEND_DIR.parent


def _csv_env(name: str, default: str) -> list[str]:
    return [item.strip() for item in os.getenv(name, default).split(",") if item.strip()]


@dataclass
class Config:
    ENV: str = os.getenv("FLASK_ENV", "development")
    DEBUG: bool = os.getenv("FLASK_DEBUG", "0") == "1"
    JSON_SORT_KEYS: bool = False

    HOST: str = os.getenv("HOST", "127.0.0.1")
    PORT: int = int(os.getenv("PORT", "8000"))

    CORS_ORIGINS: list[str] = field(default_factory=lambda: _csv_env(
        "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"))

    MODEL_PATH: Path = Path(os.getenv("MODEL_PATH", BACKEND_DIR / "artifacts" / "model.joblib"))
    #: Train on first boot if no artifact is present. Convenient locally,
    #: switch off in production where the artifact is baked into the image.
    TRAIN_ON_STARTUP: bool = os.getenv("TRAIN_ON_STARTUP", "1") == "1"

    #: Only matches on or after this date are used (applied by fetch_results.py).
    HISTORY_START: str = os.getenv("HISTORY_START", "2005-01-01")

    MAX_SCORELINES: int = int(os.getenv("MAX_SCORELINES", "8"))


def get_config() -> Config:
    return Config()
