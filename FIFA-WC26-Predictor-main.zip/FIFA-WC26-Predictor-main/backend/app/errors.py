"""One JSON error shape for every failure, so the client never has to guess."""
from __future__ import annotations

from flask import Flask, jsonify
from werkzeug.exceptions import HTTPException


class ApiError(Exception):
    def __init__(self, message: str, status: int = 400, details: dict | None = None):
        super().__init__(message)
        self.message = message
        self.status = status
        self.details = details or {}


class ModelNotReady(ApiError):
    def __init__(self, message: str = "The model has not been trained yet. Run `make train`."):
        super().__init__(message, status=503)


def _payload(error: str, message: str, status: int, details: dict | None = None) -> dict:
    body = {"error": error, "message": message, "status": status}
    if details:
        body["details"] = details
    return body


def register_error_handlers(app: Flask) -> None:
    @app.errorhandler(ApiError)
    def _api_error(exc: ApiError):
        return jsonify(_payload(type(exc).__name__, exc.message, exc.status, exc.details)), exc.status

    @app.errorhandler(HTTPException)
    def _http_error(exc: HTTPException):
        return jsonify(_payload(exc.name, exc.description or "", exc.code or 500)), exc.code or 500

    @app.errorhandler(Exception)
    def _unexpected(exc: Exception):
        app.logger.exception("Unhandled error")
        message = str(exc) if app.config.get("DEBUG") else "Internal server error"
        return jsonify(_payload("InternalServerError", message, 500)), 500
