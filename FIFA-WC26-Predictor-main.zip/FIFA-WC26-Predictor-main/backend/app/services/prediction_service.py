"""The web layer's single point of contact with the model.

Holds exactly one trained pipeline per process, behind a lock, and hides every
detail of how it got there. Routes call these methods; nothing in ``app/``
imports from ``ml/`` directly, so the model can be rebuilt, re-tuned or swapped
for something else without a single route changing.
"""
from __future__ import annotations

import logging
import threading
from pathlib import Path

from app.errors import ApiError, ModelNotReady
from ml.io import load_fixtures
from ml.pipeline import PredictionPipeline

log = logging.getLogger(__name__)


class PredictionService:
    def __init__(self, model_path: Path, train_on_startup: bool = True):
        self.model_path = Path(model_path)
        self.train_on_startup = train_on_startup
        self._pipeline: PredictionPipeline | None = None
        self._lock = threading.Lock()
        self._team_index: dict[str, str] = {}

    # ------------------------------------------------------------- lifecycle
    def ensure_ready(self) -> PredictionPipeline:
        if self._pipeline is not None:
            return self._pipeline
        with self._lock:
            if self._pipeline is not None:
                return self._pipeline

            if self.model_path.exists():
                try:
                    log.info("Loading model artifact from %s", self.model_path)
                    self._pipeline = PredictionPipeline.load(self.model_path)
                except Exception:
                    # A stale or half-written artifact must not take the API
                    # down; fall through and rebuild it from source data.
                    log.exception("Artifact at %s could not be loaded", self.model_path)
                    self._pipeline = None

            if self._pipeline is None:
                if not self.train_on_startup:
                    raise ModelNotReady()
                log.info("No usable artifact - training from source data")
                pipeline = PredictionPipeline()
                pipeline.train(verbose=False)
                try:
                    pipeline.save(self.model_path)
                except OSError:
                    log.warning("Could not persist artifact to %s", self.model_path)
                self._pipeline = pipeline

            self._team_index = {t["name"].casefold(): t["name"]
                                for t in self._pipeline.teams()}
            return self._pipeline

    def reload(self) -> None:
        with self._lock:
            self._pipeline = None
        self.ensure_ready()

    # ----------------------------------------------------------------- reads
    def resolve_team(self, name: str) -> str:
        self.ensure_ready()
        key = name.strip().casefold()
        if key in self._team_index:
            return self._team_index[key]
        close = [v for k, v in self._team_index.items() if key in k or k in key][:5]
        raise ApiError(f"Unknown team: {name!r}", status=404,
                       details={"did_you_mean": close} if close else {})

    def teams(self) -> list[dict]:
        return self.ensure_ready().teams()

    def predict(self, home: str, away: str, neutral: bool = True,
                knockout: bool = False) -> dict:
        pipeline = self.ensure_ready()
        return pipeline.predict(self.resolve_team(home), self.resolve_team(away),
                                neutral=neutral, knockout=knockout)

    def score_grid(self, home: str, away: str, neutral: bool = True) -> dict:
        pipeline = self.ensure_ready()
        return pipeline.score_grid(self.resolve_team(home), self.resolve_team(away),
                                   neutral=neutral)

    def report(self) -> dict:
        pipeline = self.ensure_ready()
        if pipeline.report is None:
            raise ModelNotReady("No training report is attached to this artifact")
        from dataclasses import asdict
        return asdict(pipeline.report)

    def fixtures(self) -> list[dict]:
        df = load_fixtures()
        return [] if df.empty else df.to_dict(orient="records")

    def elo_table(self, limit: int = 50) -> list[dict]:
        pipeline = self.ensure_ready()
        teams = pipeline.teams()[:limit]
        return [{"rank": i + 1, **t} for i, t in enumerate(teams)]
