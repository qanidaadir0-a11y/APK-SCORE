"""Modelling layer: data loading, Elo, Dixon-Coles, features, backtesting.

Deliberately framework-free — it imports nothing from Flask, so the whole
pipeline can be driven from a notebook, a CLI, a scheduled job, or a different
web layer without modification.
"""
from ml.elo import EloEngine, EloConfig
from ml.dixon_coles import DixonColesModel, DixonColesConfig
from ml.pipeline import PredictionPipeline, TrainResult

__all__ = [
    "EloEngine", "EloConfig",
    "DixonColesModel", "DixonColesConfig",
    "PredictionPipeline", "TrainResult",
]
