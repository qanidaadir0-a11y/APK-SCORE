"""Walk-forward evaluation.

A random train/test split on time-ordered data is a lie: it lets the model see
2022 while predicting 2014. Everything here is **expanding-window
walk-forward** — train on everything up to time *t*, predict the next block,
roll forward, never look back. It is the same protocol you would use to
evaluate a trading signal, for the same reason.

Each fold is scored against four baselines so the headline number means
something:

* uniform (1/3, 1/3, 1/3) — the no-information floor;
* the training-set class prior — the "just bet the base rate" floor;
* Elo alone — does history-only already explain it?
* Dixon-Coles alone — does the goal model already explain it?

A stacked model that cannot beat all four does not justify its complexity.
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
import pandas as pd

from ml import metrics
from ml.classifier import ClassifierConfig, MatchClassifier


@dataclass(frozen=True)
class BacktestConfig:
    n_folds: int = 5
    min_train: int = 96
    embargo: int = 0        # matches skipped between train and test (leakage guard)


def _elo_only_proba(X: pd.DataFrame) -> np.ndarray:
    """Elo expectancy spread into a 3-way market with a fixed draw share."""
    e = X["elo_expectancy"].to_numpy(dtype=float)
    draw = 0.24 * (1.0 - 2.0 * np.abs(e - 0.5)) + 0.12
    home = np.clip(e - draw / 2.0, 1e-6, None)
    away = np.clip(1.0 - e - draw / 2.0, 1e-6, None)
    out = np.column_stack([home, draw, away])
    return out / out.sum(axis=1, keepdims=True)


def _dc_only_proba(X: pd.DataFrame) -> np.ndarray:
    home = 1.0 / (1.0 + np.exp(-X["dc_logit_home"].to_numpy(dtype=float)))
    away = 1.0 / (1.0 + np.exp(-X["dc_logit_away"].to_numpy(dtype=float)))
    draw = X["dc_draw_prob"].to_numpy(dtype=float)
    out = np.column_stack([home, draw, away])
    return out / out.sum(axis=1, keepdims=True)


def walk_forward(X: pd.DataFrame, y: np.ndarray,
                 config: BacktestConfig | None = None,
                 clf_config: ClassifierConfig | None = None) -> dict:
    config = config or BacktestConfig()
    clf_config = clf_config or ClassifierConfig()
    n = len(X)
    if n <= config.min_train + config.n_folds:
        raise ValueError(f"Not enough rows ({n}) for {config.n_folds} folds "
                         f"with min_train={config.min_train}")

    bounds = np.linspace(config.min_train, n, config.n_folds + 1).astype(int)
    folds = []
    oos_true, oos_proba = [], []

    for f in range(config.n_folds):
        train_end = bounds[f]
        test_start = train_end + config.embargo
        test_end = bounds[f + 1]
        if test_start >= test_end:
            continue

        X_tr, y_tr = X.iloc[:train_end], y[:train_end]
        X_te, y_te = X.iloc[test_start:test_end], y[test_start:test_end]
        if len(np.unique(y_tr)) < 3 or len(X_te) == 0:
            continue

        model = MatchClassifier(clf_config).fit(X_tr, y_tr)
        proba = model.predict_proba(X_te)

        oos_true.append(y_te)
        oos_proba.append(proba)
        folds.append({
            "fold": f + 1,
            "train_n": int(len(X_tr)),
            "test_n": int(len(X_te)),
            "stack": metrics.summarise(y_te, proba, "stack"),
            "uniform": metrics.summarise(y_te, metrics.uniform_baseline(len(y_te)), "uniform"),
            "class_prior": metrics.summarise(y_te, metrics.class_prior_baseline(y_tr, len(y_te)), "class_prior"),
            "elo_only": metrics.summarise(y_te, _elo_only_proba(X_te), "elo_only"),
            "dixon_coles_only": metrics.summarise(y_te, _dc_only_proba(X_te), "dixon_coles_only"),
        })

    if not folds:
        raise RuntimeError("Walk-forward produced no usable folds")

    y_oos = np.concatenate(oos_true)
    p_oos = np.vstack(oos_proba)

    pooled = {
        "stack": metrics.summarise(y_oos, p_oos, "stack"),
        "uniform": metrics.summarise(y_oos, metrics.uniform_baseline(len(y_oos)), "uniform"),
        "class_prior": metrics.summarise(y_oos, metrics.class_prior_baseline(y, len(y_oos)), "class_prior"),
        "elo_only": metrics.summarise(y_oos, _elo_only_proba(X.iloc[-len(y_oos):]), "elo_only"),
        "dixon_coles_only": metrics.summarise(y_oos, _dc_only_proba(X.iloc[-len(y_oos):]), "dixon_coles_only"),
    }

    variants = _compare_variants(X, y, config, clf_config)

    return {
        "variants": variants,
        "config": {"n_folds": config.n_folds, "min_train": config.min_train, "embargo": config.embargo},
        "folds": folds,
        "pooled_out_of_sample": pooled,
        "calibration": metrics.calibration_table(y_oos, p_oos).to_dict(orient="records"),
        "n_out_of_sample": int(len(y_oos)),
        "skill_vs_uniform": {
            "log_loss_improvement": round(
                pooled["uniform"]["log_loss"] - pooled["stack"]["log_loss"], 4),
            "rps_improvement": round(pooled["uniform"]["rps"] - pooled["stack"]["rps"], 4),
        },
    }


def _compare_variants(X: pd.DataFrame, y: np.ndarray,
                      config: BacktestConfig, base: ClassifierConfig) -> list[dict]:
    """Evidence for the two choices most likely to be questioned.

    Class re-weighting and probability calibration both sound like unambiguous
    improvements. On a proper scoring rule they are not, so the report carries
    the comparison rather than an assertion.
    """
    from dataclasses import replace
    out = []
    for label, cfg in (
        ("default", base),
        ("class_weight=balanced", replace(base, class_weight="balanced")),
        ("uncalibrated", replace(base, calibrate=False)),
    ):
        try:
            sub = _walk_forward_core(X, y, config, cfg)
            out.append({"variant": label, **{k: v for k, v in sub.items()
                                             if k in ("accuracy", "log_loss", "brier_score", "rps", "ece")}})
        except Exception as exc:  # pragma: no cover - diagnostics only
            out.append({"variant": label, "error": str(exc)})
    return out


def _walk_forward_core(X: pd.DataFrame, y: np.ndarray,
                       config: BacktestConfig, clf_config: ClassifierConfig) -> dict:
    """Pooled out-of-sample score for one configuration (no nested variants)."""
    n = len(X)
    bounds = np.linspace(config.min_train, n, config.n_folds + 1).astype(int)
    trues, probas = [], []
    for f in range(config.n_folds):
        train_end, test_end = bounds[f], bounds[f + 1]
        test_start = train_end + config.embargo
        if test_start >= test_end:
            continue
        X_tr, y_tr = X.iloc[:train_end], y[:train_end]
        if len(np.unique(y_tr)) < 3:
            continue
        model = MatchClassifier(clf_config).fit(X_tr, y_tr)
        trues.append(y[test_start:test_end])
        probas.append(model.predict_proba(X.iloc[test_start:test_end]))
    if not trues:
        raise RuntimeError("no usable folds")
    return metrics.summarise(np.concatenate(trues), np.vstack(probas))
