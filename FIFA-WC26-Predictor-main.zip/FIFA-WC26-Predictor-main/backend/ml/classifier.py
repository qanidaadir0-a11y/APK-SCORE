"""Level-1 classifier: features -> P(home win, draw, away win).

Multinomial logistic regression, on purpose. It is the right default when the
output has to be a *calibrated probability* rather than a label, its
coefficients are directly readable as log-odds contributions, and with ~300
training rows anything with more capacity would memorise the corpus. The
scaffolding around it is where the work is:

* **Standardisation** inside the pipeline, so scaling is refitted on each
  training fold and never leaks test-fold statistics.
* **Class-imbalance handling.** Draws are roughly a fifth of outcomes but are
  three-way ties in expectation, and an unweighted fit quietly stops predicting
  them at all. ``class_weight="balanced"`` restores them.
* **Probability calibration.** Re-weighting classes distorts the probability
  scale, so the weighted fit is wrapped in a Platt/sigmoid calibration over a
  *time-series* split — never a shuffled K-fold, which would train on the
  future.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import TimeSeriesSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

from ml.features import CLASSES, FEATURE_NAMES


@dataclass(frozen=True)
class ClassifierConfig:
    C: float = 0.25                    # inverse L2 strength; small corpus -> strong shrinkage
    # Draws are ~22% of outcomes. `class_weight="balanced"` lifts draw recall
    # but measurably worsens log loss, Brier and RPS on the walk-forward -- see
    # docs/MODEL.md. Left off by default and compared explicitly in the report.
    class_weight: str | None = None
    max_iter: int = 2000
    calibrate: bool = True
    calibration_method: str = "sigmoid"
    calibration_splits: int = 4
    seed: int = 7


def build_estimator(config: ClassifierConfig) -> Pipeline:
    return Pipeline([
        ("scale", StandardScaler()),
        ("logit", LogisticRegression(
            C=config.C,
            class_weight=config.class_weight,
            max_iter=config.max_iter,
            solver="lbfgs",
            random_state=config.seed,
        )),
    ])


@dataclass
class MatchClassifier:
    config: ClassifierConfig = field(default_factory=ClassifierConfig)
    estimator: object | None = None
    calibrated_: bool = False
    feature_names: list[str] = field(default_factory=lambda: list(FEATURE_NAMES))

    def fit(self, X: pd.DataFrame, y: np.ndarray) -> "MatchClassifier":
        X = X[self.feature_names]
        base = build_estimator(self.config)

        n_classes_present = len(np.unique(y))
        can_calibrate = (
            self.config.calibrate
            and len(y) >= 60
            and n_classes_present == len(CLASSES)
            and np.bincount(y, minlength=3).min() >= self.config.calibration_splits + 1
        )
        if can_calibrate:
            splitter = TimeSeriesSplit(n_splits=self.config.calibration_splits)
            self.estimator = CalibratedClassifierCV(
                estimator=base, method=self.config.calibration_method, cv=splitter)
            self.estimator.fit(X, y)
            self.calibrated_ = True
        else:
            base.fit(X, y)
            self.estimator = base
            self.calibrated_ = False
        return self

    def predict_proba(self, X: pd.DataFrame) -> np.ndarray:
        if self.estimator is None:
            raise RuntimeError("Classifier is not fitted")
        proba = self.estimator.predict_proba(X[self.feature_names])
        classes = np.asarray(getattr(self.estimator, "classes_", np.arange(3)), dtype=int)
        full = np.zeros((len(X), 3))
        for col, cls in enumerate(classes):
            full[:, cls] = proba[:, col]
        row_sums = full.sum(axis=1, keepdims=True)
        return full / np.maximum(row_sums, 1e-12)

    # -------------------------------------------------------- interpretation
    def coefficients(self) -> pd.DataFrame:
        """Per-class log-odds coefficients on standardised features.

        Because the inputs are standardised, the magnitudes are directly
        comparable: this is the closest a linear model gets to a feature
        importance that actually means something.
        """
        pipelines = []
        if isinstance(self.estimator, Pipeline):
            pipelines = [self.estimator]
        else:
            for cc in getattr(self.estimator, "calibrated_classifiers_", []):
                inner = getattr(cc, "estimator", None)
                if isinstance(inner, Pipeline):
                    pipelines.append(inner)
        if not pipelines:
            return pd.DataFrame()

        coefs = np.mean([p.named_steps["logit"].coef_ for p in pipelines], axis=0)
        frame = pd.DataFrame(coefs.T, index=self.feature_names,
                             columns=[CLASSES[i] for i in range(coefs.shape[0])])
        frame["abs_mean"] = frame.abs().mean(axis=1)
        return frame.sort_values("abs_mean", ascending=False)
