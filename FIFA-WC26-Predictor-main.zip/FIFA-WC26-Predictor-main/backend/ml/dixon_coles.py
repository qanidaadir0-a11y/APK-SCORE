"""Dixon-Coles bivariate Poisson goal model, fitted by penalised MLE.

Why this model rather than "predict the winner" directly:

* It predicts the **distribution of the scoreline**, from which win/draw/loss,
  over/under, clean sheets and the knockout shoot-out branch all fall out. One
  fitted object, many derived quantities — the same reason a vol surface is
  modelled rather than each option quoted independently.
* It is a parametric latent-factor model: every team gets an attack and a
  defence coefficient in log-goal space, so the fitted parameters are readable.
* Dixon & Coles (1997) showed independent Poisson under-prices 0-0, 1-0, 0-1
  and 1-1. The ``rho`` correction fixes exactly those four cells.

Two extensions of the textbook model, both of which matter here:

* **Exponential time decay** (Dixon-Coles §4): a match from 2006 should not
  count as much as one from 2022. ``half_life_days`` sets the decay.
* **Shrinkage to an EA FC 25 prior.** The likelihood alone cannot say anything
  about a team with no matches in the corpus, and a World Cup always has
  those. Instead of dropping them, each team's attack/defence coefficient is
  ridge-penalised toward a prior derived from its game ratings. A team with a
  long history is driven by its results; a team with none collapses exactly
  onto its ratings prior; teams in between blend smoothly. This is ordinary
  empirical-Bayes shrinkage, and it is how the brief's two data sources are
  actually fused rather than merely concatenated.

Fitted with a hand-written Adam optimiser over analytic gradients, so the
module depends on NumPy alone.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class DixonColesConfig:
    half_life_days: float = 1460.0     # 4 years: one World Cup cycle
    max_goals: int = 10                # truncation of the scoreline grid
    ridge_attack: float = 6.0          # strength of shrinkage toward the ratings prior
    ridge_defence: float = 6.0
    prior_scale: float = 0.030         # log-goals per point of EA rating
    learning_rate: float = 0.05
    n_iterations: int = 1200
    tolerance: float = 1e-8
    rho_bound: float = 0.20
    seed: int = 7


@dataclass
class DixonColesModel:
    config: DixonColesConfig = field(default_factory=DixonColesConfig)
    teams: list[str] = field(default_factory=list)
    attack: np.ndarray | None = None
    defence: np.ndarray | None = None
    home_advantage: float = 0.25
    neutral_advantage: float = 0.0
    rho: float = -0.05
    log_likelihood_: float = float("nan")
    n_matches_: int = 0
    converged_: bool = False

    # ------------------------------------------------------------- internals
    def _index(self) -> dict[str, int]:
        return {t: i for i, t in enumerate(self.teams)}

    @staticmethod
    def _tau(x: np.ndarray, y: np.ndarray, lam: np.ndarray, mu: np.ndarray, rho: float):
        """Dixon-Coles low-score correction and its partial derivatives."""
        tau = np.ones_like(lam)
        d_lam = np.zeros_like(lam)
        d_mu = np.zeros_like(lam)
        d_rho = np.zeros_like(lam)

        m00 = (x == 0) & (y == 0)
        m01 = (x == 0) & (y == 1)
        m10 = (x == 1) & (y == 0)
        m11 = (x == 1) & (y == 1)

        tau[m00] = 1.0 - lam[m00] * mu[m00] * rho
        d_lam[m00] = -mu[m00] * rho
        d_mu[m00] = -lam[m00] * rho
        d_rho[m00] = -lam[m00] * mu[m00]

        tau[m01] = 1.0 + lam[m01] * rho
        d_lam[m01] = rho
        d_rho[m01] = lam[m01]

        tau[m10] = 1.0 + mu[m10] * rho
        d_mu[m10] = rho
        d_rho[m10] = mu[m10]

        tau[m11] = 1.0 - rho
        d_rho[m11] = -1.0

        tau = np.maximum(tau, 1e-10)
        return tau, d_lam, d_mu, d_rho

    def _rates(self, hi, ai, neutral, attack, defence, home_adv, neutral_adv):
        log_lam = attack[hi] - defence[ai] + home_adv * (1.0 - neutral) + neutral_adv * neutral
        log_mu = attack[ai] - defence[hi]
        return np.exp(np.clip(log_lam, -4, 3)), np.exp(np.clip(log_mu, -4, 3))

    # ------------------------------------------------------------------- fit
    def fit(self, matches: pd.DataFrame, ratings: pd.DataFrame | None = None,
            reference_date: pd.Timestamp | None = None) -> "DixonColesModel":
        cfg = self.config
        if matches.empty:
            raise ValueError("Cannot fit Dixon-Coles on an empty match history")

        teams = sorted(set(matches["home_team"]) | set(matches["away_team"]))
        if ratings is not None:
            teams = sorted(set(teams) | set(map(str, ratings.index)))
        self.teams = teams
        idx = self._index()
        n = len(teams)

        hi = matches["home_team"].map(idx).to_numpy(dtype=int)
        ai = matches["away_team"].map(idx).to_numpy(dtype=int)
        x = matches["home_score"].to_numpy(dtype=int)
        y = matches["away_score"].to_numpy(dtype=int)
        neutral = matches.get("neutral", pd.Series(1, index=matches.index)).to_numpy(dtype=float)

        ref = reference_date if reference_date is not None else matches["date"].max()
        age_days = (pd.Timestamp(ref) - matches["date"]).dt.days.to_numpy(dtype=float)
        decay = np.exp(-np.log(2.0) * np.maximum(age_days, 0.0) / cfg.half_life_days)
        weight = decay * matches.get("stage_weight", pd.Series(1.0, index=matches.index)).to_numpy(dtype=float)
        weight = weight / weight.mean()

        # --- empirical-Bayes priors from the EA FC 25 ratings -----------------
        att_prior = np.zeros(n)
        def_prior = np.zeros(n)
        if ratings is not None and not ratings.empty:
            centre_a = float(ratings["attack"].mean())
            centre_d = float(ratings["defence"].mean())
            for t, i in idx.items():
                if t in ratings.index:
                    att_prior[i] = cfg.prior_scale * (float(ratings.loc[t, "attack"]) - centre_a)
                    # a *better* defence must lower the opponent's rate, so the
                    # sign is positive here and enters lambda with a minus.
                    def_prior[i] = cfg.prior_scale * (float(ratings.loc[t, "defence"]) - centre_d)

        # --- parameters -------------------------------------------------------
        rng = np.random.default_rng(cfg.seed)
        attack = att_prior + 0.01 * rng.standard_normal(n)
        defence = def_prior + 0.01 * rng.standard_normal(n)
        home_adv = float(self.home_advantage)
        neutral_adv = float(self.neutral_advantage)
        rho_raw = float(np.arctanh(np.clip(self.rho, -0.9, 0.9) / 1.0))

        params = [attack, defence, np.array([home_adv]), np.array([neutral_adv]), np.array([rho_raw])]
        m_state = [np.zeros_like(p) for p in params]
        v_state = [np.zeros_like(p) for p in params]
        b1, b2, eps = 0.9, 0.999, 1e-8

        prev_obj = -np.inf
        for step in range(1, cfg.n_iterations + 1):
            attack, defence = params[0], params[1]
            home_adv, neutral_adv = params[2][0], params[3][0]
            rho = cfg.rho_bound * np.tanh(params[4][0])

            lam, mu = self._rates(hi, ai, neutral, attack, defence, home_adv, neutral_adv)
            tau, dtau_dlam, dtau_dmu, dtau_drho = self._tau(x, y, lam, mu, rho)

            ll = np.sum(weight * (np.log(tau) + x * np.log(lam) - lam + y * np.log(mu) - mu))
            pen = (0.5 * cfg.ridge_attack * np.sum((attack - att_prior) ** 2)
                   + 0.5 * cfg.ridge_defence * np.sum((defence - def_prior) ** 2))
            obj = ll - pen

            # d(objective)/d(lambda) and d/d(mu), per match
            g_lam = weight * (x / lam - 1.0 + dtau_dlam / tau)
            g_mu = weight * (y / mu - 1.0 + dtau_dmu / tau)
            # chain through the exponential link
            gl, gm = g_lam * lam, g_mu * mu

            g_attack = np.zeros(n)
            g_defence = np.zeros(n)
            np.add.at(g_attack, hi, gl)
            np.add.at(g_attack, ai, gm)
            np.add.at(g_defence, ai, -gl)
            np.add.at(g_defence, hi, -gm)
            g_attack -= cfg.ridge_attack * (attack - att_prior)
            g_defence -= cfg.ridge_defence * (defence - def_prior)

            g_home = np.array([np.sum(gl * (1.0 - neutral))])
            g_neutral = np.array([np.sum(gl * neutral)])
            g_rho_inner = np.sum(weight * dtau_drho / tau)
            g_rho = np.array([g_rho_inner * cfg.rho_bound * (1.0 - np.tanh(params[4][0]) ** 2)])

            grads = [g_attack, g_defence, g_home, g_neutral, g_rho]

            for i, (p, g) in enumerate(zip(params, grads)):
                m_state[i] = b1 * m_state[i] + (1 - b1) * g
                v_state[i] = b2 * v_state[i] + (1 - b2) * g * g
                m_hat = m_state[i] / (1 - b1 ** step)
                v_hat = v_state[i] / (1 - b2 ** step)
                params[i] = p + cfg.learning_rate * m_hat / (np.sqrt(v_hat) + eps)

            if step > 50 and abs(obj - prev_obj) < cfg.tolerance * max(1.0, abs(prev_obj)):
                self.converged_ = True
                break
            prev_obj = obj

        self.attack = params[0]
        self.defence = params[1]
        self.home_advantage = float(params[2][0])
        self.neutral_advantage = float(params[3][0])
        self.rho = float(cfg.rho_bound * np.tanh(params[4][0]))
        self.log_likelihood_ = float(prev_obj)
        self.n_matches_ = int(len(matches))
        return self

    # --------------------------------------------------------------- predict
    def expected_goals(self, home: str, away: str, neutral: bool = True) -> tuple[float, float]:
        if self.attack is None:
            raise RuntimeError("Model is not fitted")
        idx = self._index()
        if home not in idx or away not in idx:
            raise KeyError(f"Unknown team: {home if home not in idx else away}")
        h, a = idx[home], idx[away]
        nb = 1.0 if neutral else 0.0
        lam = np.exp(self.attack[h] - self.defence[a]
                     + self.home_advantage * (1 - nb) + self.neutral_advantage * nb)
        mu = np.exp(self.attack[a] - self.defence[h])
        return float(lam), float(mu)

    def score_matrix(self, home: str, away: str, neutral: bool = True) -> np.ndarray:
        """Joint P(home goals = i, away goals = j), Dixon-Coles corrected."""
        lam, mu = self.expected_goals(home, away, neutral=neutral)
        k = np.arange(self.config.max_goals + 1)
        log_fact = np.cumsum(np.log(np.maximum(k, 1)))
        p_home = np.exp(k * np.log(lam) - lam - log_fact)
        p_away = np.exp(k * np.log(mu) - mu - log_fact)
        mat = np.outer(p_home, p_away)

        rho = self.rho
        mat[0, 0] *= 1.0 - lam * mu * rho
        mat[0, 1] *= 1.0 + lam * rho
        mat[1, 0] *= 1.0 + mu * rho
        mat[1, 1] *= 1.0 - rho
        mat = np.maximum(mat, 0.0)
        return mat / mat.sum()

    def outcome_probabilities(self, home: str, away: str, neutral: bool = True) -> dict[str, float]:
        mat = self.score_matrix(home, away, neutral=neutral)
        home_win = float(np.tril(mat, -1).sum())
        away_win = float(np.triu(mat, 1).sum())
        draw = float(np.trace(mat))
        total = home_win + draw + away_win
        return {"home_win": home_win / total, "draw": draw / total, "away_win": away_win / total}

    def team_table(self) -> pd.DataFrame:
        """Fitted attack / defence coefficients, in log-goal units."""
        return (pd.DataFrame({"team": self.teams, "attack": self.attack, "defence": self.defence})
                .assign(net=lambda d: d["attack"] + d["defence"])
                .sort_values("net", ascending=False)
                .reset_index(drop=True))

    def to_dict(self) -> dict:
        return {
            "teams": list(self.teams),
            "attack": np.asarray(self.attack).tolist(),
            "defence": np.asarray(self.defence).tolist(),
            "home_advantage": self.home_advantage,
            "neutral_advantage": self.neutral_advantage,
            "rho": self.rho,
            "log_likelihood": self.log_likelihood_,
            "n_matches": self.n_matches_,
            "config": self.config.__dict__,
        }

    @classmethod
    def from_dict(cls, payload: dict) -> "DixonColesModel":
        cfg = DixonColesConfig(**payload.get("config", {}))
        model = cls(config=cfg)
        model.teams = list(payload["teams"])
        model.attack = np.array(payload["attack"], dtype=float)
        model.defence = np.array(payload["defence"], dtype=float)
        model.home_advantage = float(payload["home_advantage"])
        model.neutral_advantage = float(payload["neutral_advantage"])
        model.rho = float(payload["rho"])
        model.log_likelihood_ = float(payload.get("log_likelihood", float("nan")))
        model.n_matches_ = int(payload.get("n_matches", 0))
        return model
