"""A weighted Elo engine for international football.

Elo is the project's memory of *history*. It is strictly causal: every rating
is the value that existed immediately **before** the match it is attached to,
which is what makes the backtest in ``ml/backtest.py`` honest.

Two departures from chess Elo, both standard in football rating work:

* **Goal-difference weighting** (FIFA / World Football Elo): the K factor is
  scaled by a concave function of margin, so a 5-0 moves ratings more than a
  1-0 but not five times more.
* **Match-importance weighting**: a World Cup final moves ratings more than a
  group opener, via ``stage_weight``.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class EloConfig:
    k_factor: float = 40.0
    home_advantage: float = 65.0      # in Elo points, applied only when not neutral
    scale: float = 400.0              # points per factor-of-10 odds
    initial: float = 1500.0
    regress_to_mean: float = 0.0      # optional per-match shrinkage, 0 = off
    prior_weight: float = 0.0         # blend of the ratings-derived prior into `initial`


@dataclass
class EloEngine:
    config: EloConfig = field(default_factory=EloConfig)
    ratings: dict[str, float] = field(default_factory=dict)
    games_played: dict[str, int] = field(default_factory=dict)
    priors: dict[str, float] = field(default_factory=dict)

    # ------------------------------------------------------------------ core
    def rating(self, team: str) -> float:
        if team not in self.ratings:
            self.ratings[team] = self.priors.get(team, self.config.initial)
            self.games_played.setdefault(team, 0)
        return self.ratings[team]

    def expected_score(self, home: str, away: str, neutral: bool = True) -> float:
        """P(home wins) in the Elo sense — a win-or-half-a-draw expectation."""
        adv = 0.0 if neutral else self.config.home_advantage
        diff = (self.rating(home) + adv) - self.rating(away)
        return 1.0 / (1.0 + 10.0 ** (-diff / self.config.scale))

    @staticmethod
    def margin_multiplier(goal_diff: int) -> float:
        """Concave weighting of the goal margin (World Football Elo convention)."""
        g = abs(int(goal_diff))
        if g <= 1:
            return 1.0
        if g == 2:
            return 1.5
        return (11.0 + g) / 8.0

    def update(self, home: str, away: str, home_score: int, away_score: int,
               neutral: bool = True, stage_weight: float = 1.0) -> tuple[float, float]:
        """Apply one match. Returns the *pre-match* ratings (home, away)."""
        pre_home, pre_away = self.rating(home), self.rating(away)

        expected = self.expected_score(home, away, neutral=neutral)
        if home_score > away_score:
            actual = 1.0
        elif home_score == away_score:
            actual = 0.5
        else:
            actual = 0.0

        k = self.config.k_factor * self.margin_multiplier(home_score - away_score) * float(stage_weight)
        delta = k * (actual - expected)

        self.ratings[home] = pre_home + delta
        self.ratings[away] = pre_away - delta
        self.games_played[home] = self.games_played.get(home, 0) + 1
        self.games_played[away] = self.games_played.get(away, 0) + 1

        if self.config.regress_to_mean:
            lam = self.config.regress_to_mean
            for t in (home, away):
                anchor = self.priors.get(t, self.config.initial)
                self.ratings[t] = (1 - lam) * self.ratings[t] + lam * anchor

        return pre_home, pre_away

    # ------------------------------------------------------------- batch API
    def seed_from_ratings(self, ratings_df: pd.DataFrame, points_per_ovr: float = 22.0) -> None:
        """Anchor unseen teams to an EA-FC-25-derived prior instead of a flat 1500.

        Without this, a team with no match history in the corpus starts level
        with Brazil. Mapping `overall` onto Elo points gives every team a
        defensible starting point and makes cold-start predictions sane.
        """
        overall = ratings_df["overall"].astype(float)
        centre = float(overall.mean())
        self.priors = {
            team: self.config.initial + points_per_ovr * (float(value) - centre)
            for team, value in overall.items()
        }

    def run(self, matches: pd.DataFrame) -> pd.DataFrame:
        """Stream a match history, returning pre-match ratings per row.

        The returned frame is aligned to ``matches`` and contains only
        information available before kick-off — safe to use as model features.
        """
        rows = []
        for m in matches.itertuples(index=False):
            pre_h, pre_a = self.update(
                m.home_team, m.away_team, int(m.home_score), int(m.away_score),
                neutral=bool(getattr(m, "neutral", 1)),
                stage_weight=float(getattr(m, "stage_weight", 1.0)),
            )
            rows.append({
                "elo_home_pre": pre_h,
                "elo_away_pre": pre_a,
                "elo_diff": pre_h - pre_a,
                "elo_home_games": self.games_played[m.home_team] - 1,
                "elo_away_games": self.games_played[m.away_team] - 1,
            })
        return pd.DataFrame(rows, index=matches.index)

    def snapshot(self) -> pd.Series:
        return pd.Series(self.ratings, name="elo").sort_values(ascending=False)

    def copy(self) -> "EloEngine":
        return EloEngine(self.config, dict(self.ratings), dict(self.games_played), dict(self.priors))
