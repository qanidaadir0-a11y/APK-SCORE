"""Causal feature engineering.

Every feature answers one question: *what was knowable the moment before
kick-off?* Getting that wrong is the single most common way a sports- or
price-prediction backtest flatters itself, so the design matrix is built by a
strictly forward, one-pass sweep through the match history. Nothing is ever
computed from a `groupby` over the whole frame.

The Dixon-Coles outcome probabilities are stacked in as features, refitted on
an expanding window of past matches only — a standard two-level stack, with
the level-0 model's out-of-sample output feeding the level-1 classifier.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from ml.dixon_coles import DixonColesConfig, DixonColesModel
from ml.elo import EloConfig, EloEngine
from ml.io import REPLACEMENT_LEVEL, rating_vector

FORM_WINDOW = 5
EPS = 1e-6

FEATURE_NAMES = [
    "elo_diff",
    "elo_expectancy",
    "rating_overall_diff",
    "home_att_vs_away_def",
    "away_att_vs_home_def",
    "midfield_diff",
    "form_ppg_diff",
    "form_gd_diff",
    "form_gf_diff",
    "experience_diff",
    "rest_days_diff",
    "neutral",
    "knockout",
    "same_confederation",
    "dc_logit_home",
    "dc_logit_away",
    "dc_draw_prob",
    "dc_xg_diff",
    "dc_xg_total",
]

# class order used everywhere: 0 = home win, 1 = draw, 2 = away win
CLASSES = ("home_win", "draw", "away_win")


def outcome_class(home_score: int, away_score: int) -> int:
    if home_score > away_score:
        return 0
    if home_score == away_score:
        return 1
    return 2


def _logit(p: float) -> float:
    p = min(max(float(p), 1e-6), 1 - 1e-6)
    return float(np.log(p / (1 - p)))


@dataclass
class TeamForm:
    """Rolling, strictly backward-looking form for one team."""
    points: deque = field(default_factory=lambda: deque(maxlen=FORM_WINDOW))
    goals_for: deque = field(default_factory=lambda: deque(maxlen=FORM_WINDOW))
    goals_against: deque = field(default_factory=lambda: deque(maxlen=FORM_WINDOW))
    played: int = 0
    last_date: pd.Timestamp | None = None

    def snapshot(self) -> dict[str, float]:
        n = len(self.points)
        if n == 0:
            return {"ppg": 1.0, "gf": 1.1, "ga": 1.1, "gd": 0.0, "played": 0}
        gf = sum(self.goals_for) / n
        ga = sum(self.goals_against) / n
        return {"ppg": sum(self.points) / n, "gf": gf, "ga": ga, "gd": gf - ga, "played": self.played}

    def update(self, gf: int, ga: int, date: pd.Timestamp) -> None:
        self.points.append(3 if gf > ga else (1 if gf == ga else 0))
        self.goals_for.append(gf)
        self.goals_against.append(ga)
        self.played += 1
        self.last_date = date


@dataclass
class FeatureState:
    """Everything needed to featurise a *future* fixture, after training."""
    elo: EloEngine
    form: dict[str, TeamForm]
    dixon_coles: DixonColesModel
    ratings: pd.DataFrame
    last_date: pd.Timestamp


def _static_pair_features(home: str, away: str, ratings: pd.DataFrame) -> dict[str, float]:
    h = rating_vector(home, ratings)
    a = rating_vector(away, ratings)
    return {
        "rating_overall_diff": h.overall - a.overall,
        "home_att_vs_away_def": h.attack - a.defence,
        "away_att_vs_home_def": a.attack - h.defence,
        "midfield_diff": h.midfield - a.midfield,
        "same_confederation": float(bool(h.confederation) and h.confederation == a.confederation),
    }


def featurise_fixture(state: FeatureState, home: str, away: str,
                      neutral: bool = True, knockout: bool = False,
                      match_date: pd.Timestamp | None = None) -> tuple[pd.DataFrame, dict]:
    """Build the single-row design matrix for an unplayed fixture."""
    match_date = pd.Timestamp(match_date) if match_date is not None else state.last_date

    elo_h = state.elo.rating(home)
    elo_a = state.elo.rating(away)
    fh = state.form.get(home, TeamForm()).snapshot()
    fa = state.form.get(away, TeamForm()).snapshot()

    lh = state.form.get(home, TeamForm()).last_date
    la = state.form.get(away, TeamForm()).last_date
    rest_h = (match_date - lh).days if lh is not None else 30.0
    rest_a = (match_date - la).days if la is not None else 30.0

    try:
        lam, mu = state.dixon_coles.expected_goals(home, away, neutral=neutral)
        dc = state.dixon_coles.outcome_probabilities(home, away, neutral=neutral)
    except KeyError:
        lam = mu = 1.2
        dc = {"home_win": 0.40, "draw": 0.26, "away_win": 0.34}

    row = {
        "elo_diff": elo_h - elo_a,
        "elo_expectancy": state.elo.expected_score(home, away, neutral=neutral),
        "form_ppg_diff": fh["ppg"] - fa["ppg"],
        "form_gd_diff": fh["gd"] - fa["gd"],
        "form_gf_diff": fh["gf"] - fa["gf"],
        "experience_diff": np.log1p(fh["played"]) - np.log1p(fa["played"]),
        "rest_days_diff": float(np.clip(rest_h - rest_a, -60, 60)),
        "neutral": float(neutral),
        "knockout": float(knockout),
        "dc_logit_home": _logit(dc["home_win"]),
        "dc_logit_away": _logit(dc["away_win"]),
        "dc_draw_prob": float(dc["draw"]),
        "dc_xg_diff": lam - mu,
        "dc_xg_total": lam + mu,
    }
    row.update(_static_pair_features(home, away, state.ratings))
    X = pd.DataFrame([[row[name] for name in FEATURE_NAMES]], columns=FEATURE_NAMES)
    context = {
        "elo_home": elo_h, "elo_away": elo_a,
        "xg_home": lam, "xg_away": mu,
        "dixon_coles": dc,
        "form_home": fh, "form_away": fa,
    }
    return X, context


def build_training_set(results: pd.DataFrame, ratings: pd.DataFrame,
                       min_history: int = 64, refit_every: int = 32,
                       elo_config: EloConfig | None = None,
                       dc_config: DixonColesConfig | None = None,
                       verbose: bool = False) -> tuple[pd.DataFrame, np.ndarray, pd.DataFrame, FeatureState]:
    """Sweep the history forward once, emitting one causal feature row per match.

    Returns ``(X, y, meta, state)``. ``state`` carries the fully-updated Elo,
    form and Dixon-Coles objects, ready to featurise future fixtures.
    """
    elo = EloEngine(elo_config or EloConfig())
    elo.seed_from_ratings(ratings)
    form: dict[str, TeamForm] = {}
    dc_config = dc_config or DixonColesConfig()

    dc_model: DixonColesModel | None = None
    rows: list[dict] = []
    targets: list[int] = []
    meta: list[dict] = []

    results = results.reset_index(drop=True)
    for i, m in enumerate(results.itertuples(index=False)):
        # ---- refit the level-0 goal model on the past only -----------------
        if i >= min_history and (dc_model is None or (i - min_history) % refit_every == 0):
            window = results.iloc[:i]
            dc_model = DixonColesModel(config=dc_config).fit(
                window, ratings=ratings, reference_date=m.date)
            if verbose:
                print(f"  refit Dixon-Coles at match {i} on {len(window)} prior matches")

        neutral = bool(getattr(m, "neutral", 1))
        knockout = float(getattr(m, "stage_weight", 1.0)) > 1.0

        if dc_model is not None:
            state = FeatureState(elo, form, dc_model, ratings, m.date)
            X_row, _ = featurise_fixture(state, m.home_team, m.away_team,
                                         neutral=neutral, knockout=knockout, match_date=m.date)
            rows.append(X_row.iloc[0].to_dict())
            targets.append(outcome_class(int(m.home_score), int(m.away_score)))
            meta.append({"date": m.date, "home_team": m.home_team, "away_team": m.away_team,
                         "home_score": int(m.home_score), "away_score": int(m.away_score),
                         "tournament": getattr(m, "tournament", ""),
                         "stage": getattr(m, "stage", "")})

        # ---- then, and only then, let the match update the state ------------
        elo.update(m.home_team, m.away_team, int(m.home_score), int(m.away_score),
                   neutral=neutral, stage_weight=float(getattr(m, "stage_weight", 1.0)))
        form.setdefault(m.home_team, TeamForm()).update(int(m.home_score), int(m.away_score), m.date)
        form.setdefault(m.away_team, TeamForm()).update(int(m.away_score), int(m.home_score), m.date)

    final_dc = DixonColesModel(config=dc_config).fit(results, ratings=ratings)
    final_state = FeatureState(elo, form, final_dc, ratings, results["date"].max())

    X = pd.DataFrame(rows, columns=FEATURE_NAMES)
    y = np.asarray(targets, dtype=int)
    return X, y, pd.DataFrame(meta), final_state
