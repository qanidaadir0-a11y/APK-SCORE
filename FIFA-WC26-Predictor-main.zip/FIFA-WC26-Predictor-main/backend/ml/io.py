"""Loading and normalising the two raw data sources."""
from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

DATA_DIR = Path(__file__).resolve().parents[2] / "data"
RAW_DIR = DATA_DIR / "raw"

RESULTS_CORE = RAW_DIR / "international_results.csv"
RESULTS_FULL = RAW_DIR / "international_results_full.csv"
RATINGS_FILE = RAW_DIR / "ea_fc25_national_ratings.csv"
ALIASES_FILE = RAW_DIR / "team_aliases.csv"
FIXTURES_FILE = RAW_DIR / "wc26_fixtures.csv"

RESULT_COLUMNS = [
    "date", "home_team", "away_team", "home_score", "away_score",
    "tournament", "stage", "stage_code", "stage_weight", "neutral",
]


@lru_cache(maxsize=1)
def load_aliases() -> dict[str, str]:
    if not ALIASES_FILE.exists():
        return {}
    df = pd.read_csv(ALIASES_FILE)
    return dict(zip(df["alias"].astype(str), df["canonical"].astype(str)))


def canonicalise(names: pd.Series) -> pd.Series:
    """Map naming variants onto one canonical team name."""
    aliases = load_aliases()
    return names.astype(str).str.strip().replace(aliases)


def load_results(path: Path | None = None) -> pd.DataFrame:
    """Load match history, newest last.

    Prefers the expanded corpus written by ``scripts/fetch_results.py`` and
    falls back to the bundled World Cup core so the repo trains offline.
    """
    if path is None:
        path = RESULTS_FULL if RESULTS_FULL.exists() else RESULTS_CORE
    df = pd.read_csv(path)

    missing = [c for c in ("date", "home_team", "away_team", "home_score", "away_score") if c not in df.columns]
    if missing:
        raise ValueError(f"{path.name} is missing required columns: {missing}")

    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date", "home_score", "away_score"])
    df["home_team"] = canonicalise(df["home_team"])
    df["away_team"] = canonicalise(df["away_team"])
    df["home_score"] = df["home_score"].astype(int)
    df["away_score"] = df["away_score"].astype(int)

    for col, default in (("tournament", "Unknown"), ("stage", "Unknown"),
                         ("stage_code", "G1"), ("stage_weight", 1.0), ("neutral", 1)):
        if col not in df.columns:
            df[col] = default
    df["stage_weight"] = pd.to_numeric(df["stage_weight"], errors="coerce").fillna(1.0)
    df["neutral"] = pd.to_numeric(df["neutral"], errors="coerce").fillna(1).astype(int)

    df = df[df["home_team"] != df["away_team"]]
    df = df.sort_values(["date", "home_team", "away_team"], kind="mergesort").reset_index(drop=True)
    df["outcome"] = np.sign(df["home_score"] - df["away_score"]).astype(int)  # 1 home, 0 draw, -1 away
    return df


@lru_cache(maxsize=1)
def load_ratings() -> pd.DataFrame:
    """EA FC 25 national-team ratings, indexed by canonical team name."""
    df = pd.read_csv(RATINGS_FILE)
    df["team"] = canonicalise(df["team"])
    for col in ("overall", "attack", "midfield", "defence"):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.dropna(subset=["overall"]).drop_duplicates(subset=["team"], keep="first")
    return df.set_index("team").sort_index()


def load_fixtures() -> pd.DataFrame:
    if not FIXTURES_FILE.exists():
        return pd.DataFrame()
    df = pd.read_csv(FIXTURES_FILE)
    df["home_team"] = canonicalise(df["home_team"])
    df["away_team"] = canonicalise(df["away_team"])
    return df


@dataclass(frozen=True)
class RatingVector:
    """One team's EA FC 25 profile, plus the replacement-level fallback."""
    team: str
    overall: float
    attack: float
    midfield: float
    defence: float
    confederation: str
    fifa_code: str
    known: bool


REPLACEMENT_LEVEL = 62.0


def rating_vector(team: str, ratings: pd.DataFrame | None = None) -> RatingVector:
    """Look a team up, returning a replacement-level profile if it is unrated.

    An unrated team is not an error: the World Cup draw regularly produces
    debutants. They are handled explicitly rather than silently dropped.
    """
    ratings = load_ratings() if ratings is None else ratings
    if team in ratings.index:
        r = ratings.loc[team]
        return RatingVector(team, float(r["overall"]), float(r["attack"]),
                            float(r["midfield"]), float(r["defence"]),
                            str(r.get("confederation", "")), str(r.get("fifa_code", "")), True)
    return RatingVector(team, REPLACEMENT_LEVEL, REPLACEMENT_LEVEL,
                        REPLACEMENT_LEVEL, REPLACEMENT_LEVEL, "", "", False)
