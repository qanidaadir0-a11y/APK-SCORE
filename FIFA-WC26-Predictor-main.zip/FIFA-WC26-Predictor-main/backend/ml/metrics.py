"""Scoring rules for probabilistic forecasts.

Accuracy alone is close to useless for a three-way market: a model that says
"home win, 40%" on every match can post a respectable hit rate while being
worthless to anyone sizing a position. What matters is whether the stated
probabilities are *right*, which is what proper scoring rules measure.

* **Log loss** — the strictly proper rule. Punishes confident errors hard; it
  is the loss the classifier is actually fitted against.
* **Multiclass Brier score** — proper, bounded, less brutal on tail misses.
* **Ranked Probability Score** — the standard metric in football forecasting
  because the outcome is *ordered* (home / draw / away). RPS gives partial
  credit for being one step out, which log loss and Brier do not.
* **Calibration** — bucket forecasts by stated probability and compare against
  realised frequency. A model can have good log loss and still be
  systematically overconfident; the reliability table is where that shows up.
* **Expected Calibration Error** — the reliability table as one number.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

N_CLASSES = 3


def _prep(y_true: np.ndarray, proba: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    y_true = np.asarray(y_true, dtype=int)
    proba = np.clip(np.asarray(proba, dtype=float), 1e-12, 1.0)
    proba = proba / proba.sum(axis=1, keepdims=True)
    return y_true, proba


def log_loss(y_true, proba) -> float:
    y_true, proba = _prep(y_true, proba)
    return float(-np.mean(np.log(proba[np.arange(len(y_true)), y_true])))


def brier_score(y_true, proba) -> float:
    """Multiclass Brier: mean squared error against the one-hot outcome."""
    y_true, proba = _prep(y_true, proba)
    onehot = np.eye(N_CLASSES)[y_true]
    return float(np.mean(np.sum((proba - onehot) ** 2, axis=1)))


def ranked_probability_score(y_true, proba) -> float:
    """RPS for an ordered 3-outcome market (Constantinou & Fenton, 2012)."""
    y_true, proba = _prep(y_true, proba)
    onehot = np.eye(N_CLASSES)[y_true]
    cum_p = np.cumsum(proba, axis=1)[:, :-1]
    cum_o = np.cumsum(onehot, axis=1)[:, :-1]
    return float(np.mean(np.sum((cum_p - cum_o) ** 2, axis=1) / (N_CLASSES - 1)))


def accuracy(y_true, proba) -> float:
    y_true, proba = _prep(y_true, proba)
    return float(np.mean(proba.argmax(axis=1) == y_true))


def calibration_table(y_true, proba, n_bins: int = 10) -> pd.DataFrame:
    """Reliability table over every (match, class) forecast."""
    y_true, proba = _prep(y_true, proba)
    onehot = np.eye(N_CLASSES)[y_true]
    p = proba.ravel()
    o = onehot.ravel()
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    bucket = np.clip(np.digitize(p, edges, right=True) - 1, 0, n_bins - 1)
    rows = []
    for b in range(n_bins):
        mask = bucket == b
        if not mask.any():
            continue
        rows.append({
            "bin": f"{edges[b]:.1f}-{edges[b + 1]:.1f}",
            "n": int(mask.sum()),
            "mean_predicted": float(p[mask].mean()),
            "observed_frequency": float(o[mask].mean()),
            "gap": float(p[mask].mean() - o[mask].mean()),
        })
    return pd.DataFrame(rows)


def expected_calibration_error(y_true, proba, n_bins: int = 10) -> float:
    table = calibration_table(y_true, proba, n_bins=n_bins)
    if table.empty:
        return float("nan")
    w = table["n"] / table["n"].sum()
    return float(np.sum(w * table["gap"].abs()))


def summarise(y_true, proba, label: str = "model") -> dict:
    return {
        "label": label,
        "n": int(len(y_true)),
        "accuracy": round(accuracy(y_true, proba), 4),
        "log_loss": round(log_loss(y_true, proba), 4),
        "brier_score": round(brier_score(y_true, proba), 4),
        "rps": round(ranked_probability_score(y_true, proba), 4),
        "ece": round(expected_calibration_error(y_true, proba), 4),
    }


# ----------------------------------------------------------------- baselines
def uniform_baseline(n: int) -> np.ndarray:
    return np.full((n, N_CLASSES), 1.0 / N_CLASSES)


def class_prior_baseline(y_train: np.ndarray, n: int) -> np.ndarray:
    counts = np.bincount(np.asarray(y_train, dtype=int), minlength=N_CLASSES) + 1.0
    return np.tile(counts / counts.sum(), (n, 1))
