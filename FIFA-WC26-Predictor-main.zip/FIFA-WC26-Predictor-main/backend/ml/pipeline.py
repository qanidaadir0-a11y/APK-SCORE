"""End-to-end orchestration: train once, persist, serve many.

``PredictionPipeline`` is the only object the web layer knows about. It owns
the Elo state, the Dixon-Coles goal model, the stacked classifier and the
backtest report, and it turns a fixture into the full payload the UI renders:
three-way probabilities, expected goals, the scoreline grid, the most likely
correct scores, and — for knockout ties — the extra-time and shoot-out branch.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np
import pandas as pd

from ml import metrics
from ml.backtest import BacktestConfig, walk_forward
from ml.classifier import ClassifierConfig, MatchClassifier
from ml.dixon_coles import DixonColesConfig, DixonColesModel
from ml.elo import EloConfig, EloEngine
from ml.features import (CLASSES, FEATURE_NAMES, FeatureState, TeamForm,
                         build_training_set, featurise_fixture)
from ml.io import load_ratings, load_results, rating_vector

ARTIFACT_DIR = Path(__file__).resolve().parents[1] / "artifacts"
MODEL_FILE = ARTIFACT_DIR / "model.joblib"
REPORT_FILE = ARTIFACT_DIR / "report.json"

SCHEMA_VERSION = "1.0.0"


@dataclass
class TrainResult:
    trained_at: str
    n_matches: int
    n_training_rows: int
    n_teams: int
    date_range: tuple[str, str]
    in_sample: dict
    backtest: dict
    feature_importance: list[dict]
    dixon_coles: dict
    top_elo: list[dict]


@dataclass
class PredictionPipeline:
    elo_config: EloConfig = field(default_factory=EloConfig)
    dc_config: DixonColesConfig = field(default_factory=DixonColesConfig)
    clf_config: ClassifierConfig = field(default_factory=ClassifierConfig)
    backtest_config: BacktestConfig = field(default_factory=BacktestConfig)

    classifier: MatchClassifier | None = None
    state: FeatureState | None = None
    report: TrainResult | None = None

    # ------------------------------------------------------------------ train
    def train(self, results: pd.DataFrame | None = None,
              ratings: pd.DataFrame | None = None,
              run_backtest: bool = True, verbose: bool = True) -> TrainResult:
        results = load_results() if results is None else results
        ratings = load_ratings() if ratings is None else ratings

        if verbose:
            print(f"Training on {len(results)} matches "
                  f"({results['date'].min():%Y-%m-%d} to {results['date'].max():%Y-%m-%d})")

        X, y, meta, state = build_training_set(
            results, ratings,
            min_history=max(self.backtest_config.min_train // 2, 32),
            elo_config=self.elo_config, dc_config=self.dc_config, verbose=False)
        if verbose:
            print(f"Built {len(X)} causal feature rows x {len(FEATURE_NAMES)} features")

        backtest = {}
        if run_backtest:
            backtest = walk_forward(X, y, self.backtest_config, self.clf_config)
            if verbose:
                p = backtest["pooled_out_of_sample"]
                print(f"Walk-forward OOS ({backtest['n_out_of_sample']} matches): "
                      f"acc {p['stack']['accuracy']:.3f} | logloss {p['stack']['log_loss']:.4f} "
                      f"| RPS {p['stack']['rps']:.4f}  (uniform RPS {p['uniform']['rps']:.4f})")

        self.classifier = MatchClassifier(self.clf_config).fit(X, y)
        self.state = state

        in_sample_proba = self.classifier.predict_proba(X)
        importance = self.classifier.coefficients()
        elo_snapshot = state.elo.snapshot()

        self.report = TrainResult(
            trained_at=datetime.now(timezone.utc).isoformat(timespec="seconds"),
            n_matches=int(len(results)),
            n_training_rows=int(len(X)),
            n_teams=int(len(state.dixon_coles.teams)),
            date_range=(str(results["date"].min().date()), str(results["date"].max().date())),
            in_sample=metrics.summarise(y, in_sample_proba, "in_sample"),
            backtest=backtest,
            feature_importance=(importance.round(4).reset_index()
                                .rename(columns={"index": "feature"})
                                .to_dict(orient="records") if not importance.empty else []),
            dixon_coles={
                "rho": round(state.dixon_coles.rho, 4),
                "home_advantage": round(state.dixon_coles.home_advantage, 4),
                "neutral_advantage": round(state.dixon_coles.neutral_advantage, 4),
                "log_likelihood": round(state.dixon_coles.log_likelihood_, 2),
                "converged": bool(state.dixon_coles.converged_),
                "half_life_days": self.dc_config.half_life_days,
            },
            top_elo=[{"team": t, "elo": round(float(v), 1)}
                     for t, v in elo_snapshot.head(25).items()],
        )
        return self.report

    # ---------------------------------------------------------------- predict
    def teams(self) -> list[dict]:
        """Every team the model can price, with its inputs."""
        if self.state is None:
            raise RuntimeError("Pipeline is not trained")
        ratings = self.state.ratings
        out = []
        for team in sorted(set(self.state.dixon_coles.teams) | set(map(str, ratings.index))):
            rv = rating_vector(team, ratings)
            form = self.state.form.get(team, TeamForm()).snapshot()
            out.append({
                "name": team,
                "code": rv.fifa_code,
                "confederation": rv.confederation,
                "overall": rv.overall,
                "attack": rv.attack,
                "midfield": rv.midfield,
                "defence": rv.defence,
                "rated": rv.known,
                "elo": round(float(self.state.elo.rating(team)), 1),
                "matches_in_corpus": int(form["played"]),
            })
        return sorted(out, key=lambda t: -t["elo"])

    def _knockout_branch(self, home: str, away: str, neutral: bool,
                         regulation: dict) -> dict:
        """Extra time, then penalties. Returns P(each side advances)."""
        lam, mu = self.state.dixon_coles.expected_goals(home, away, neutral=neutral)
        # 30 minutes of extra time, with the usual cautious-football discount
        et_lam, et_mu = lam / 3.0 * 0.85, mu / 3.0 * 0.85
        k = np.arange(7)
        logf = np.cumsum(np.log(np.maximum(k, 1)))
        p_h = np.exp(k * np.log(et_lam) - et_lam - logf)
        p_a = np.exp(k * np.log(et_mu) - et_mu - logf)
        et = np.outer(p_h, p_a)
        et = et / et.sum()
        et_home = float(np.tril(et, -1).sum())
        et_away = float(np.triu(et, 1).sum())
        et_draw = float(np.trace(et))

        # Shoot-outs are close to a coin flip; nudge only slightly by quality.
        rh = rating_vector(home, self.state.ratings).overall
        ra = rating_vector(away, self.state.ratings).overall
        pen_home = float(np.clip(0.5 + 0.006 * (rh - ra), 0.40, 0.60))

        d = regulation["draw"]
        advance_home = (regulation["home_win"]
                        + d * (et_home + et_draw * pen_home))
        advance_away = 1.0 - advance_home
        return {
            "reaches_extra_time": round(d, 4),
            "reaches_penalties": round(d * et_draw, 4),
            "extra_time": {"home_win": round(et_home, 4), "draw": round(et_draw, 4),
                           "away_win": round(et_away, 4)},
            "penalty_edge_home": round(pen_home, 4),
            "advance_home": round(float(advance_home), 4),
            "advance_away": round(float(advance_away), 4),
        }

    def predict(self, home: str, away: str, neutral: bool = True,
                knockout: bool = False, top_scores: int = 6) -> dict:
        if self.classifier is None or self.state is None:
            raise RuntimeError("Pipeline is not trained")

        X, context = featurise_fixture(self.state, home, away,
                                       neutral=neutral, knockout=knockout)
        proba = self.classifier.predict_proba(X)[0]
        outcome = {CLASSES[i]: round(float(proba[i]), 4) for i in range(3)}

        matrix = self.state.dixon_coles.score_matrix(home, away, neutral=neutral)
        flat = [(int(i), int(j), float(matrix[i, j]))
                for i in range(matrix.shape[0]) for j in range(matrix.shape[1])]
        flat.sort(key=lambda t: -t[2])
        scorelines = [{"home": i, "away": j, "probability": round(p, 4)}
                      for i, j, p in flat[:top_scores]]

        lam, mu = context["xg_home"], context["xg_away"]
        entropy = float(-np.sum(proba * np.log(np.clip(proba, 1e-12, 1))) / np.log(3))

        result = {
            "schema_version": SCHEMA_VERSION,
            "fixture": {"home_team": home, "away_team": away,
                        "neutral": bool(neutral), "knockout": bool(knockout)},
            "probabilities": outcome,
            "most_likely_outcome": max(outcome, key=outcome.get),
            "confidence": round(1.0 - entropy, 4),
            "expected_goals": {"home": round(lam, 3), "away": round(mu, 3),
                               "total": round(lam + mu, 3)},
            "scorelines": scorelines,
            "predicted_scoreline": {"home": scorelines[0]["home"], "away": scorelines[0]["away"]},
            "markets": {
                "both_teams_to_score": round(float(1.0 - matrix[0, :].sum() - matrix[:, 0].sum()
                                                   + matrix[0, 0]), 4),
                "over_2_5_goals": round(float(sum(p for i, j, p in flat if i + j > 2)), 4),
                "home_clean_sheet": round(float(matrix[:, 0].sum()), 4),
                "away_clean_sheet": round(float(matrix[0, :].sum()), 4),
            },
            "model_inputs": {
                "elo": {"home": round(context["elo_home"], 1), "away": round(context["elo_away"], 1),
                        "diff": round(context["elo_home"] - context["elo_away"], 1)},
                "ratings": {
                    "home": rating_vector(home, self.state.ratings).__dict__,
                    "away": rating_vector(away, self.state.ratings).__dict__,
                },
                "form": {"home": context["form_home"], "away": context["form_away"]},
                "dixon_coles_only": {k: round(v, 4) for k, v in context["dixon_coles"].items()},
            },
            "features": {name: round(float(X.iloc[0][name]), 4) for name in FEATURE_NAMES},
        }
        if knockout:
            result["knockout"] = self._knockout_branch(home, away, neutral, outcome)
        return result

    def score_grid(self, home: str, away: str, neutral: bool = True, max_goals: int = 6) -> dict:
        matrix = self.state.dixon_coles.score_matrix(home, away, neutral=neutral)
        m = matrix[:max_goals + 1, :max_goals + 1]
        return {"home_team": home, "away_team": away, "max_goals": max_goals,
                "grid": np.round(m, 5).tolist()}

    # ------------------------------------------------------------ persistence
    def save(self, path: Path = MODEL_FILE) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "schema_version": SCHEMA_VERSION,
            "classifier": self.classifier,
            "elo_ratings": dict(self.state.elo.ratings),
            "elo_games": dict(self.state.elo.games_played),
            "elo_priors": dict(self.state.elo.priors),
            "elo_config": asdict(self.elo_config),
            "dixon_coles": self.state.dixon_coles.to_dict(),
            "form": {t: {"points": list(f.points), "gf": list(f.goals_for),
                         "ga": list(f.goals_against), "played": f.played,
                         "last_date": None if f.last_date is None else str(f.last_date)}
                     for t, f in self.state.form.items()},
            "last_date": str(self.state.last_date),
            "report": asdict(self.report) if self.report else None,
        }
        joblib.dump(payload, path)
        if self.report is not None:
            # The report lives beside its artifact, not at a fixed path, so a
            # test or an experiment writing to a temp dir cannot clobber the
            # report belonging to the real model.
            (path.parent / "report.json").write_text(
                json.dumps(asdict(self.report), indent=2), encoding="utf-8")
        return path

    @classmethod
    def load(cls, path: Path = MODEL_FILE) -> "PredictionPipeline":
        payload = joblib.load(path)
        pipe = cls(elo_config=EloConfig(**payload["elo_config"]))
        pipe.classifier = payload["classifier"]

        elo = EloEngine(pipe.elo_config, dict(payload["elo_ratings"]),
                        dict(payload["elo_games"]), dict(payload["elo_priors"]))
        dc = DixonColesModel.from_dict(payload["dixon_coles"])
        form = {}
        for team, f in payload["form"].items():
            tf = TeamForm()
            tf.points.extend(f["points"]); tf.goals_for.extend(f["gf"])
            tf.goals_against.extend(f["ga"]); tf.played = f["played"]
            tf.last_date = pd.Timestamp(f["last_date"]) if f["last_date"] else None
            form[team] = tf

        pipe.state = FeatureState(elo, form, dc, load_ratings(),
                                  pd.Timestamp(payload["last_date"]))
        if payload.get("report"):
            pipe.report = TrainResult(**payload["report"])
        return pipe

    @staticmethod
    def artifact_exists(path: Path = MODEL_FILE) -> bool:
        return path.exists()
