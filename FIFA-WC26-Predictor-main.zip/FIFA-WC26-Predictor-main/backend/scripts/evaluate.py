#!/usr/bin/env python3
"""Score the model's forecasts against matches it has never seen.

Point this at any CSV with `home_team,away_team,home_score,away_score` — a
tournament that has since been played, a held-out season, anything — and it
returns log loss, Brier, RPS and a calibration table against the realised
results, alongside the uniform baseline.

    python scripts/evaluate.py data/raw/wc26_results.csv
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from ml import metrics  # noqa: E402
from ml.features import outcome_class  # noqa: E402
from ml.pipeline import MODEL_FILE, PredictionPipeline  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("results", type=Path, help="CSV of played matches")
    parser.add_argument("--model", type=Path, default=MODEL_FILE)
    parser.add_argument("--neutral", action="store_true", default=True)
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    pipeline = PredictionPipeline.load(args.model)
    df = pd.read_csv(args.results)

    y, proba, skipped = [], [], []
    for row in df.itertuples(index=False):
        try:
            out = pipeline.predict(row.home_team, row.away_team, neutral=args.neutral)
        except KeyError:
            skipped.append(f"{row.home_team} v {row.away_team}")
            continue
        p = out["probabilities"]
        proba.append([p["home_win"], p["draw"], p["away_win"]])
        y.append(outcome_class(int(row.home_score), int(row.away_score)))

    if not y:
        print("No evaluable matches found.")
        return 1

    y = np.asarray(y)
    proba = np.asarray(proba)
    summary = {
        "n_evaluated": len(y),
        "n_skipped": len(skipped),
        "model": metrics.summarise(y, proba, "model"),
        "uniform": metrics.summarise(y, metrics.uniform_baseline(len(y)), "uniform"),
        "calibration": metrics.calibration_table(y, proba).to_dict(orient="records"),
    }
    if args.json:
        print(json.dumps(summary, indent=2))
    else:
        m, u = summary["model"], summary["uniform"]
        print(f"\n  {len(y)} matches evaluated"
              + (f" ({len(skipped)} skipped: unknown teams)" if skipped else "") + "\n")
        print(f"  {'':<12}{'acc':>8}{'log loss':>11}{'Brier':>9}{'RPS':>9}{'ECE':>9}")
        print("  " + "-" * 58)
        for label, row in (("model", m), ("uniform", u)):
            print(f"  {label:<12}{row['accuracy']:>8.3f}{row['log_loss']:>11.4f}"
                  f"{row['brier_score']:>9.4f}{row['rps']:>9.4f}{row['ece']:>9.4f}")
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
