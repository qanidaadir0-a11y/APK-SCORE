#!/usr/bin/env python3
"""Expand the training corpus from the open international-results dataset.

The bundled corpus is every match of the last five World Cups — clean and
complete, but finals only. This pulls the full international record
(qualifiers, continental tournaments, friendlies; ~48,000 matches since 1872)
from the openly-licensed martj42/international_results project, normalises team
names through `data/raw/team_aliases.csv`, and writes
`data/raw/international_results_full.csv`, which the loader then prefers.

    python scripts/fetch_results.py                  # 2005 onward
    python scripts/fetch_results.py --since 1990
    python scripts/fetch_results.py --competitive    # drop friendlies
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from ml.io import RAW_DIR, canonicalise  # noqa: E402

SOURCE = ("https://raw.githubusercontent.com/martj42/international_results/"
          "master/results.csv")

#: How much a result moves the Elo rating, by competition type.
STAGE_WEIGHTS = {
    "FIFA World Cup": 1.25,
    "FIFA World Cup qualification": 1.10,
    "UEFA Euro": 1.15,
    "Copa América": 1.15,
    "African Cup of Nations": 1.10,
    "AFC Asian Cup": 1.10,
    "Gold Cup": 1.05,
    "UEFA Nations League": 1.05,
    "Confederations Cup": 1.05,
    "Friendly": 0.70,
}


def stage_weight(tournament: str) -> float:
    for key, weight in STAGE_WEIGHTS.items():
        if key.casefold() in str(tournament).casefold():
            return weight
    return 1.0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--since", default="2005-01-01")
    parser.add_argument("--competitive", action="store_true", help="exclude friendlies")
    parser.add_argument("--source", default=SOURCE)
    parser.add_argument("--out", type=Path, default=RAW_DIR / "international_results_full.csv")
    args = parser.parse_args()

    print(f"Downloading {args.source}")
    try:
        raw = pd.read_csv(args.source)
    except Exception as exc:
        print(f"\n  Could not download the dataset: {exc}")
        print("  The bundled World Cup corpus in data/raw/international_results.csv")
        print("  is still complete and the model trains from it with no network.\n")
        return 1

    print(f"  {len(raw):,} rows downloaded")
    df = raw.rename(columns={"home_score": "home_score", "away_score": "away_score"})
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date", "home_score", "away_score"])
    df = df[df["date"] >= pd.Timestamp(args.since)]
    if args.competitive:
        df = df[~df["tournament"].str.contains("Friendly", case=False, na=False)]

    out = pd.DataFrame({
        "date": df["date"].dt.date.astype(str),
        "home_team": canonicalise(df["home_team"]),
        "away_team": canonicalise(df["away_team"]),
        "home_score": df["home_score"].astype(int),
        "away_score": df["away_score"].astype(int),
        "tournament": df["tournament"],
        "stage": df["tournament"],
        "stage_code": "NA",
        "stage_weight": df["tournament"].map(stage_weight),
        "neutral": df["neutral"].astype(int) if "neutral" in df else 1,
    })
    out = out[out["home_team"] != out["away_team"]].sort_values("date")

    args.out.parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.out, index=False)
    teams = len(set(out["home_team"]) | set(out["away_team"]))
    print(f"  Wrote {len(out):,} matches ({teams} teams) -> {args.out}")
    print("\n  Now run: python scripts/train.py\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
