#!/usr/bin/env python3
"""Train the pipeline, print the report, persist the artifact.

    python scripts/train.py                 # train, backtest, save
    python scripts/train.py --no-backtest   # fast path for iteration
    python scripts/train.py --folds 8
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from ml.backtest import BacktestConfig          # noqa: E402
from ml.classifier import ClassifierConfig      # noqa: E402
from ml.pipeline import MODEL_FILE, PredictionPipeline  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Train the World Cup predictor")
    parser.add_argument("--no-backtest", action="store_true", help="skip walk-forward validation")
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--min-train", type=int, default=96)
    parser.add_argument("--C", type=float, default=0.25, dest="c")
    parser.add_argument("--class-weight", default=None, choices=[None, "balanced"])
    parser.add_argument("--out", type=Path, default=MODEL_FILE)
    parser.add_argument("--json", action="store_true", help="print the full report as JSON")
    args = parser.parse_args()

    pipeline = PredictionPipeline(
        clf_config=ClassifierConfig(C=args.c, class_weight=args.class_weight),
        backtest_config=BacktestConfig(n_folds=args.folds, min_train=args.min_train),
    )
    report = pipeline.train(run_backtest=not args.no_backtest)
    path = pipeline.save(args.out)

    if args.json:
        from dataclasses import asdict
        print(json.dumps(asdict(report), indent=2))
    else:
        print()
        print("=" * 74)
        print(f"  Trained on {report.n_matches} matches "
              f"({report.date_range[0]} to {report.date_range[1]}) | {report.n_teams} teams")
        print("=" * 74)
        if report.backtest:
            pooled = report.backtest["pooled_out_of_sample"]
            print(f"\n  Walk-forward, {report.backtest['n_out_of_sample']} out-of-sample matches\n")
            print(f"  {'model':<20}{'acc':>8}{'log loss':>11}{'Brier':>9}{'RPS':>9}{'ECE':>9}")
            print("  " + "-" * 64)
            for name in ("uniform", "class_prior", "elo_only", "dixon_coles_only", "stack"):
                m = pooled[name]
                mark = "  <-- shipped" if name == "stack" else ""
                print(f"  {name:<20}{m['accuracy']:>8.3f}{m['log_loss']:>11.4f}"
                      f"{m['brier_score']:>9.4f}{m['rps']:>9.4f}{m['ece']:>9.4f}{mark}")
        print("\n  Top features (standardised |coefficient|)")
        for row in report.feature_importance[:8]:
            print(f"    {row['feature']:<26}{row['abs_mean']:.3f}")
        dc = report.dixon_coles
        print(f"\n  Dixon-Coles: rho {dc['rho']:+.4f} | home adv {dc['home_advantage']:+.3f} "
              f"| neutral adv {dc['neutral_advantage']:+.3f} | converged {dc['converged']}")
        print(f"\n  Artifact -> {path}")
        print(f"  Report   -> {path.parent / 'report.json'}\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
