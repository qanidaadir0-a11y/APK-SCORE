import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from app import create_app                      # noqa: E402
from app.config import Config                   # noqa: E402
from ml.io import load_ratings, load_results     # noqa: E402
from ml.pipeline import PredictionPipeline       # noqa: E402


@pytest.fixture(scope="session")
def results():
    return load_results()


@pytest.fixture(scope="session")
def ratings():
    return load_ratings()


@pytest.fixture(scope="session")
def trained_pipeline(results, ratings):
    """One trained pipeline shared across the suite — training is the slow part."""
    pipeline = PredictionPipeline()
    pipeline.train(results, ratings, run_backtest=False, verbose=False)
    return pipeline


@pytest.fixture(scope="session")
def app(tmp_path_factory, trained_pipeline):
    artifact = tmp_path_factory.mktemp("artifacts") / "model.joblib"
    trained_pipeline.save(artifact)
    application = create_app(Config(MODEL_PATH=artifact, TRAIN_ON_STARTUP=False, DEBUG=True))
    return application


@pytest.fixture()
def client(app):
    return app.test_client()
