def test_health(client):
    body = client.get("/api/health").get_json()
    assert body["status"] == "ok"


def test_ready(client):
    assert client.get("/api/ready").status_code == 200


def test_index_lists_endpoints(client):
    body = client.get("/").get_json()
    assert any("/api/predict" in route for route in body["endpoints"])


def test_teams(client):
    body = client.get("/api/teams").get_json()
    assert body["count"] > 50
    assert {"name", "elo", "overall", "confederation"} <= set(body["teams"][0])


def test_teams_filtering(client):
    body = client.get("/api/teams?confederation=CONMEBOL").get_json()
    assert body["count"] > 0
    assert all(t["confederation"] == "CONMEBOL" for t in body["teams"])


def test_team_search(client):
    body = client.get("/api/teams?q=bra").get_json()
    assert "Brazil" in [t["name"] for t in body["teams"]]


def test_predict(client):
    res = client.post("/api/predict", json={"home_team": "Brazil", "away_team": "Argentina"})
    assert res.status_code == 200
    body = res.get_json()
    assert abs(sum(body["probabilities"].values()) - 1.0) < 1e-6
    assert body["fixture"]["home_team"] == "Brazil"


def test_predict_accepts_the_legacy_prototype_body(client):
    res = client.post("/api/predict", json={"team1": "France", "team2": "Germany"})
    assert res.status_code == 200


def test_predict_is_case_insensitive(client):
    res = client.post("/api/predict", json={"home_team": "bRaZiL", "away_team": "spain"})
    assert res.status_code == 200
    assert res.get_json()["fixture"]["home_team"] == "Brazil"


def test_knockout_flag(client):
    body = client.post("/api/predict",
                       json={"home_team": "Spain", "away_team": "Italy", "knockout": True}).get_json()
    assert "knockout" in body


def test_batch(client):
    body = client.post("/api/predict/batch", json={"fixtures": [
        {"home_team": "Brazil", "away_team": "Japan"},
        {"home_team": "Mexico", "away_team": "Canada"},
    ]}).get_json()
    assert body["count"] == 2


def test_score_grid(client):
    body = client.post("/api/predict/score-grid",
                       json={"home_team": "Spain", "away_team": "Morocco"}).get_json()
    assert len(body["grid"]) == 7


def test_unknown_team_returns_404_with_suggestions(client):
    res = client.post("/api/predict", json={"home_team": "Brazzil", "away_team": "Spain"})
    assert res.status_code == 404
    assert res.get_json()["error"] == "ApiError"


def test_self_match_is_rejected(client):
    res = client.post("/api/predict", json={"home_team": "Brazil", "away_team": "brazil"})
    assert res.status_code == 400


def test_missing_field_is_rejected(client):
    assert client.post("/api/predict", json={"home_team": "Brazil"}).status_code == 400


def test_empty_body_is_rejected(client):
    assert client.post("/api/predict", json={}).status_code == 400


def test_oversized_batch_is_rejected(client):
    fixtures = [{"home_team": "Brazil", "away_team": "Spain"}] * 40
    assert client.post("/api/predict/batch", json={"fixtures": fixtures}).status_code == 400


def test_model_metrics(client):
    body = client.get("/api/model/metrics").get_json()
    assert body["n_matches"] > 300


def test_rankings(client):
    body = client.get("/api/rankings?limit=10").get_json()
    assert len(body["rankings"]) == 10
    assert body["rankings"][0]["rank"] == 1


def test_fixtures(client):
    assert isinstance(client.get("/api/fixtures").get_json()["fixtures"], list)


def test_cors_header_present(client):
    res = client.post("/api/predict",
                      json={"home_team": "Brazil", "away_team": "Spain"},
                      headers={"Origin": "http://localhost:5173"})
    assert res.headers.get("Access-Control-Allow-Origin") == "http://localhost:5173"
