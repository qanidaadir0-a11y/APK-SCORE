"""The data is the product. If it is wrong, nothing downstream can be right."""
import pandas as pd

from ml.io import load_ratings, load_results, rating_vector


def test_results_load_and_are_chronological(results):
    assert len(results) >= 300
    assert results["date"].is_monotonic_increasing


def test_no_team_plays_itself(results):
    assert (results["home_team"] != results["away_team"]).all()


def test_scores_are_non_negative_integers(results):
    for col in ("home_score", "away_score"):
        assert results[col].dtype.kind in "iu"
        assert (results[col] >= 0).all()


def test_every_world_cup_has_a_full_bracket(results):
    """64 matches per edition — a missing fixture would silently skew Elo."""
    counts = results.groupby("tournament").size()
    for tournament, n in counts.items():
        if "World Cup" in tournament:
            assert n == 64, f"{tournament} has {n} matches, expected 64"


def test_aliases_resolve(results):
    """`Serbia and Montenegro` must not survive as a separate team."""
    teams = set(results["home_team"]) | set(results["away_team"])
    assert "Serbia and Montenegro" not in teams
    assert "Czechia" not in teams


def test_ratings_are_in_range(ratings):
    for col in ("overall", "attack", "midfield", "defence"):
        assert ratings[col].between(40, 99).all()
    assert ratings.index.is_unique


def test_every_team_in_the_corpus_has_a_rating(results, ratings):
    teams = set(results["home_team"]) | set(results["away_team"])
    missing = sorted(teams - set(ratings.index))
    assert not missing, f"unrated teams in the match corpus: {missing}"


def test_unknown_team_falls_back_to_replacement_level(ratings):
    rv = rating_vector("Atlantis", ratings)
    assert rv.known is False
    assert 50 <= rv.overall <= 70
