import numpy as np
import pytest

from ml.dixon_coles import DixonColesConfig, DixonColesModel


@pytest.fixture(scope="module")
def model(results, ratings):
    return DixonColesModel(DixonColesConfig(n_iterations=600)).fit(results, ratings=ratings)


def test_score_matrix_is_a_distribution(model):
    m = model.score_matrix("Brazil", "Argentina")
    assert m.min() >= 0
    assert abs(m.sum() - 1.0) < 1e-9


def test_outcome_probabilities_sum_to_one(model):
    p = model.outcome_probabilities("France", "Morocco")
    assert abs(sum(p.values()) - 1.0) < 1e-9


def test_stronger_team_is_favoured(model):
    p = model.outcome_probabilities("Brazil", "Seychelles")
    assert p["home_win"] > 0.8


def test_reversing_the_fixture_reverses_the_edge(model):
    a = model.outcome_probabilities("Spain", "Costa Rica", neutral=True)
    b = model.outcome_probabilities("Costa Rica", "Spain", neutral=True)
    assert a["home_win"] > a["away_win"]
    assert b["away_win"] > b["home_win"]


def test_home_advantage_is_positive(model):
    """Estimated from the data, not assumed — but it should come out positive."""
    assert model.home_advantage > 0


def test_rho_correction_only_touches_the_four_low_score_cells(model):
    m = model.score_matrix("Germany", "Japan")
    lam, mu = model.expected_goals("Germany", "Japan")
    k = np.arange(model.config.max_goals + 1)
    logf = np.cumsum(np.log(np.maximum(k, 1)))
    raw = np.outer(np.exp(k * np.log(lam) - lam - logf),
                   np.exp(k * np.log(mu) - mu - logf))
    raw /= raw.sum()
    ratio = m[2:, 2:] / raw[2:, 2:]
    assert np.allclose(ratio, ratio.flat[0], rtol=1e-6)


def test_unrated_team_with_no_history_still_prices(model, ratings):
    """Cold start: a team absent from the match corpus must still be priceable."""
    assert "Uzbekistan" in model.teams
    p = model.outcome_probabilities("Brazil", "Uzbekistan")
    assert 0.0 < p["home_win"] < 1.0


def test_round_trips_through_a_dict(model):
    clone = DixonColesModel.from_dict(model.to_dict())
    a = model.outcome_probabilities("Italy", "England")
    b = clone.outcome_probabilities("Italy", "England")
    for key in a:
        assert abs(a[key] - b[key]) < 1e-12


def test_empty_history_is_rejected(results):
    with pytest.raises(ValueError):
        DixonColesModel().fit(results.head(0))
