import pandas as pd

from ml.elo import EloConfig, EloEngine


def test_zero_sum_update():
    elo = EloEngine()
    before = elo.rating("A") + elo.rating("B")
    elo.update("A", "B", 2, 0)
    assert abs((elo.rating("A") + elo.rating("B")) - before) < 1e-9


def test_winner_gains_loser_loses():
    elo = EloEngine()
    elo.update("A", "B", 3, 1)
    assert elo.rating("A") > 1500 > elo.rating("B")


def test_draw_between_equals_is_a_no_op():
    elo = EloEngine()
    elo.update("A", "B", 1, 1, neutral=True)
    assert abs(elo.rating("A") - 1500) < 1e-9


def test_bigger_margin_moves_more():
    narrow, wide = EloEngine(), EloEngine()
    narrow.update("A", "B", 1, 0)
    wide.update("A", "B", 5, 0)
    assert wide.rating("A") > narrow.rating("A")


def test_margin_multiplier_is_concave():
    assert EloEngine.margin_multiplier(1) == 1.0
    assert EloEngine.margin_multiplier(5) < 5 * EloEngine.margin_multiplier(1)


def test_home_advantage_only_applies_off_neutral_ground():
    elo = EloEngine(EloConfig(home_advantage=100))
    assert elo.expected_score("A", "B", neutral=True) == 0.5
    assert elo.expected_score("A", "B", neutral=False) > 0.5


def test_run_returns_pre_match_ratings_only(results):
    """The whole backtest rests on this: features must precede the result."""
    elo = EloEngine()
    frame = elo.run(results.head(20))
    assert len(frame) == 20
    assert frame.iloc[0]["elo_home_pre"] == 1500.0
    assert frame.iloc[0]["elo_home_games"] == 0


def test_seeding_from_ratings_separates_strong_and_weak(ratings):
    elo = EloEngine()
    elo.seed_from_ratings(ratings)
    assert elo.rating("Brazil") > elo.rating("Seychelles")
