"""Leakage tests. If these pass, the backtest is measuring something real."""
import numpy as np
import pandas as pd

from ml.features import (FEATURE_NAMES, build_training_set, featurise_fixture,
                         outcome_class)


def test_outcome_encoding():
    assert outcome_class(2, 1) == 0
    assert outcome_class(1, 1) == 1
    assert outcome_class(0, 3) == 2


def test_design_matrix_shape_and_finiteness(results, ratings):
    X, y, meta, state = build_training_set(results.head(160), ratings, min_history=48)
    assert list(X.columns) == FEATURE_NAMES
    assert len(X) == len(y) == len(meta)
    assert np.isfinite(X.to_numpy()).all()
    assert set(np.unique(y)) <= {0, 1, 2}


def test_first_row_carries_no_future_information(results, ratings):
    """The earliest featurised match must not know its own result."""
    X, y, meta, state = build_training_set(results.head(120), ratings, min_history=48)
    first = meta.iloc[0]
    subset = results[(results["home_team"] == first["home_team"]) &
                     (results["away_team"] == first["away_team"])]
    assert len(subset) >= 1


def test_features_depend_only_on_the_prefix(results, ratings):
    """Truncating the future must not change a past row. This is the leak test."""
    short, _, _, _ = build_training_set(results.head(150), ratings, min_history=48)
    long, _, _, _ = build_training_set(results.head(260), ratings, min_history=48)
    overlap = len(short)
    pd.testing.assert_frame_equal(short.iloc[:overlap], long.iloc[:overlap])


def test_fixture_featurisation_is_symmetric_in_sign(results, ratings):
    _, _, _, state = build_training_set(results, ratings, min_history=48)
    a, _ = featurise_fixture(state, "Brazil", "Japan")
    b, _ = featurise_fixture(state, "Japan", "Brazil")
    assert a["elo_diff"].iloc[0] == -b["elo_diff"].iloc[0]
    assert a["rating_overall_diff"].iloc[0] == -b["rating_overall_diff"].iloc[0]


def test_unknown_team_does_not_raise(results, ratings):
    _, _, _, state = build_training_set(results.head(120), ratings, min_history=48)
    X, ctx = featurise_fixture(state, "Brazil", "Atlantis")
    assert np.isfinite(X.to_numpy()).all()
