import numpy as np

from ml import metrics


def test_perfect_forecast_scores_zero():
    y = np.array([0, 1, 2])
    p = np.eye(3)[y]
    assert metrics.log_loss(y, p) < 1e-6
    assert metrics.brier_score(y, p) < 1e-9
    assert metrics.ranked_probability_score(y, p) < 1e-9


def test_uniform_forecast_hits_the_known_floor():
    y = np.array([0, 1, 2, 0])
    p = metrics.uniform_baseline(4)
    assert abs(metrics.log_loss(y, p) - np.log(3)) < 1e-9


def test_rps_rewards_being_one_step_out_over_two():
    y = np.array([0])                       # home win
    near = np.array([[0.0, 1.0, 0.0]])      # said draw
    far = np.array([[0.0, 0.0, 1.0]])       # said away win
    assert metrics.ranked_probability_score(y, near) < metrics.ranked_probability_score(y, far)


def test_log_loss_cannot_tell_those_apart():
    """Exactly why RPS is reported alongside it."""
    y = np.array([0])
    near = np.array([[1e-9, 1 - 2e-9, 1e-9]])
    far = np.array([[1e-9, 1e-9, 1 - 2e-9]])
    assert abs(metrics.log_loss(y, near) - metrics.log_loss(y, far)) < 1e-6


def test_calibration_table_detects_overconfidence():
    rng = np.random.default_rng(0)
    y = rng.integers(0, 3, 600)
    p = np.zeros((600, 3))
    p[np.arange(600), rng.integers(0, 3, 600)] = 0.9
    p[p == 0] = 0.05
    assert metrics.expected_calibration_error(y, p) > 0.1


def test_probabilities_are_renormalised():
    y = np.array([0, 1])
    p = np.array([[2.0, 1.0, 1.0], [1.0, 2.0, 1.0]])
    assert np.isfinite(metrics.log_loss(y, p))
