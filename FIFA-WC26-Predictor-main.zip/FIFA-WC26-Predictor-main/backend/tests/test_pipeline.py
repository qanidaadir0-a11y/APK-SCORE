import numpy as np
import pytest


def test_probabilities_sum_to_one(trained_pipeline):
    p = trained_pipeline.predict("Brazil", "Argentina")["probabilities"]
    assert abs(sum(p.values()) - 1.0) < 1e-6


def test_prediction_payload_is_complete(trained_pipeline):
    out = trained_pipeline.predict("England", "Spain")
    for key in ("probabilities", "expected_goals", "scorelines", "markets",
                "model_inputs", "features", "confidence"):
        assert key in out
    assert len(out["scorelines"]) > 0
    assert out["scorelines"] == sorted(out["scorelines"],
                                       key=lambda s: -s["probability"])


def test_knockout_branch_only_appears_when_asked(trained_pipeline):
    assert "knockout" not in trained_pipeline.predict("France", "Croatia")
    ko = trained_pipeline.predict("France", "Croatia", knockout=True)["knockout"]
    assert abs(ko["advance_home"] + ko["advance_away"] - 1.0) < 1e-6
    assert ko["reaches_penalties"] <= ko["reaches_extra_time"]


def test_a_draw_cannot_advance_anyone(trained_pipeline):
    """In a knockout tie, P(advance) must exceed P(win in regulation)."""
    out = trained_pipeline.predict("Italy", "Germany", knockout=True)
    assert out["knockout"]["advance_home"] > out["probabilities"]["home_win"]


def test_markets_are_probabilities(trained_pipeline):
    markets = trained_pipeline.predict("Netherlands", "United States")["markets"]
    for name, value in markets.items():
        assert 0.0 <= value <= 1.0, name


def test_stronger_side_is_favoured(trained_pipeline):
    out = trained_pipeline.predict("Brazil", "Seychelles")
    assert out["probabilities"]["home_win"] > out["probabilities"]["away_win"]


def test_unknown_team_raises(trained_pipeline):
    with pytest.raises(KeyError):
        trained_pipeline.predict("Brazil", "Wakanda")


def test_score_grid_rows_are_a_distribution(trained_pipeline):
    grid = np.array(trained_pipeline.score_grid("Spain", "Morocco")["grid"])
    assert grid.min() >= 0
    assert grid.sum() <= 1.0 + 1e-9


def test_teams_are_ranked_by_elo(trained_pipeline):
    teams = trained_pipeline.teams()
    assert len(teams) > 50
    elos = [t["elo"] for t in teams]
    assert elos == sorted(elos, reverse=True)


def test_artifact_round_trip(trained_pipeline, tmp_path):
    from ml.pipeline import PredictionPipeline
    path = trained_pipeline.save(tmp_path / "m.joblib")
    reloaded = PredictionPipeline.load(path)
    a = trained_pipeline.predict("Portugal", "Uruguay")["probabilities"]
    b = reloaded.predict("Portugal", "Uruguay")["probabilities"]
    for key in a:
        assert abs(a[key] - b[key]) < 1e-9
