"""WSGI entrypoint: `gunicorn wsgi:app` or `python wsgi.py`."""
from app import create_app
from app.config import get_config

config = get_config()
app = create_app(config)

if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)
