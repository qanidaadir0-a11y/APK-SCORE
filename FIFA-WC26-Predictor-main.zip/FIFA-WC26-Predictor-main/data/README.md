# Data

Two primary signals feed the model, exactly as the project brief specifies:
national-team **history** and national-team **ratings**.

## `raw/international_results.csv` — 320 matches

Every match of the five most recent FIFA World Cup final tournaments
(2006, 2010, 2014, 2018, 2022), hand-curated and complete — 64 matches each.

| column | meaning |
| --- | --- |
| `date` | Match date. Accurate to the tournament's published stage window; matches inside a stage are spread evenly across that window, so **chronological ordering within and across tournaments is correct** (this is what Elo and the walk-forward backtest depend on). |
| `home_team`, `away_team` | Canonical team names (see `team_aliases.csv`). At a World Cup the "home" side is the first-named team on the official fixture. |
| `home_score`, `away_score` | Full-time score **including extra time**, excluding penalties. |
| `extra_time` | 1 if the match went to extra time. |
| `pens_home`, `pens_away` | Shoot-out score where one occurred. Deliberately kept out of `home_score`/`away_score` so the Poisson goal model never trains on a fabricated goal. |
| `neutral` | 1 unless the host nation is playing. |
| `stage`, `stage_code`, `stage_weight` | Round, and the weight used in the weighted Elo update (knockout matches move ratings more). |

## `raw/ea_fc25_national_ratings.csv` — 127 teams

EA SPORTS FC 25 (PS5) men's national-team ratings: `overall`, `attack`,
`midfield`, `defence`, plus confederation and FIFA code.

These are transcribed from the shipped game and are a **snapshot**, not a live
feed. Correct any value you disagree with and re-run `make train` — the
pipeline reads this file directly, so the model updates with no code change.

## `raw/wc26_fixtures.csv`

Fixture list powering the "Featured Matches" section. The rows shipped here are
marked `source=placeholder`; replace them with the real draw and the UI follows.

## `raw/team_aliases.csv`

Maps the naming variants you hit when merging sources (`Czechia` →
`Czech Republic`, `Serbia and Montenegro` → `Serbia`, and so on) onto one
canonical name. Every loader runs names through this map.

## Expanding the training set

`raw/international_results.csv` is a clean, complete, high-quality core, but it
is only World Cup finals. To train on the full international record —
qualifiers, continental tournaments and friendlies, ~48,000 matches back to
1872 — run:

```bash
make data          # or: python backend/scripts/fetch_results.py
```

This pulls the openly-licensed [martj42/international_results](https://github.com/martj42/international_results)
dataset, normalises names through `team_aliases.csv`, filters to the window in
`backend/app/config.py`, and writes `raw/international_results_full.csv`. The
trainer prefers that file when it exists and falls back to the bundled core
when it does not, so **the repo trains and serves with no network access**.

`processed/` is generated and git-ignored.
