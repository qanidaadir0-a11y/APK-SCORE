# Architecture

## The one rule

`ml/` does not import from `app/`.

The modelling layer knows nothing about Flask, HTTP, or JSON. It takes
DataFrames and returns dictionaries. Everything follows from that:

- the pipeline runs unchanged in a notebook, a cron job, or a batch scoring
  script;
- the tests for the model do not need an application context;
- swapping Flask for FastAPI, or adding a gRPC surface, touches `app/` only.

The reverse is enforced by structure too: nothing in `app/` imports from `ml/`
except `services/prediction_service.py`. Routes talk to the service; the
service talks to the model. Retraining, caching and artifact loading are all
that service's problem, and no route has to know they exist.

## Request path

```
POST /api/predict
  ↓  routes_predict.predict
  ↓  schemas.PredictRequest.parse      ← validation happens here, once
  ↓  PredictionService.predict
  ↓    .resolve_team  (case-insensitive, 404 + suggestions on miss)
  ↓    .ensure_ready  (load artifact, or train, under a lock)
  ↓  PredictionPipeline.predict
  ↓    featurise_fixture  →  classifier.predict_proba
  ↓    dixon_coles.score_matrix  →  scorelines, markets
  ↓    _knockout_branch  (only when asked)
  → JSON
```

Validation is at the edge and nowhere else. By the time a value reaches the
model it is known-good, so `ml/` contains no defensive parsing.

## Model lifecycle

`PredictionService.ensure_ready()` is the only place a model is created:

1. artifact exists → load it;
2. load fails → log, discard, fall through (a half-written artifact must not
   take the API down);
3. no usable artifact → train from source data, persist, continue.

It holds one pipeline per process behind a lock, so concurrent first requests
train once rather than *n* times. In production `TRAIN_ON_STARTUP=0` and the
artifact is baked into the image at build time, which is what
`backend/Dockerfile` does.

## Error contract

Every failure returns the same body:

```json
{ "error": "ApiError", "message": "Unknown team: 'Brazzil'", "status": 404,
  "details": { "did_you_mean": ["Brazil"] } }
```

Three handlers cover it: `ApiError` for deliberate rejections, `HTTPException`
for Werkzeug's own, and a catch-all that logs the traceback and returns a
generic message unless `DEBUG`. The frontend's `ApiError` class unwraps exactly
this shape, so an unknown-team 404 becomes a useful message rather than
"Request failed".

## Frontend

- `types/api.ts` mirrors the API contract. When the backend's shape changes,
  `tsc` points at every component that has to change with it.
- `api/client.ts` is the only place that calls `fetch`. Base URL, timeout and
  error unwrapping live there once.
- `hooks/useApi.ts` provides `useAsync` (fetch on mount) and `useAction` (fetch
  on interaction). `useAction` tracks a request id so a slow response that a
  newer request has superseded is discarded rather than flashing stale numbers
  on screen.
- Vite proxies `/api` to Flask in development and nginx does the same in
  production, so the browser only ever sees one origin and CORS never enters
  the development loop.

## Why Flask

The prototype this grew from was Flask, and the resume says Flask. More
usefully: the service layer means the web framework is a detail. `app/` is
about 300 lines. Replacing it is an afternoon, and the model would not notice.
