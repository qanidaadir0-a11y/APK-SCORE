# The model

## Notation

For a match with home team $i$ and away team $j$, the goal model assumes

$$
\begin{aligned}
X &\sim \text{Poisson}(\lambda), &\quad \log \lambda &= \alpha_i - \delta_j + \gamma \cdot \mathbb{1}[\text{not neutral}] + \gamma_0 \cdot \mathbb{1}[\text{neutral}] \\
Y &\sim \text{Poisson}(\mu),      &\quad \log \mu     &= \alpha_j - \delta_i
\end{aligned}
$$

where $\alpha$ is attack, $\delta$ is defence, $\gamma$ is true home advantage
and $\gamma_0$ is the small residual edge the first-named side holds at a
neutral venue. Both are estimated, not assumed — a World Cup is played almost
entirely on neutral ground, so a single home-advantage term would be
unidentified.

## The Dixon-Coles correction

Independent Poisson systematically mis-prices the four lowest scorelines.
Dixon & Coles (1997) multiply the joint density by

$$
\tau(x, y) =
\begin{cases}
1 - \lambda\mu\rho & x = 0, y = 0 \\
1 + \lambda\rho    & x = 0, y = 1 \\
1 + \mu\rho        & x = 1, y = 0 \\
1 - \rho           & x = 1, y = 1 \\
1                  & \text{otherwise}
\end{cases}
$$

`tests/test_dixon_coles.py::test_rho_correction_only_touches_the_four_low_score_cells`
checks this empirically: it divides the fitted score matrix by an uncorrected
Poisson outer product and asserts the ratio is constant outside the 2×2 corner.

$\rho$ is estimated from the data rather than fixed. Its sign depends on the
corpus; on World Cup finals — where extra-time goals are included in the score
— it comes out differently than it does on league data, which is worth knowing
before quoting a number from the literature.

## Time decay

Each match is weighted $w_k = 2^{-\Delta_k / h}$ where $\Delta_k$ is its age in
days and $h$ is the half-life, defaulting to 1460 days (one cycle). Weights are
normalised to mean 1 so that the ridge penalty keeps a consistent scale as the
corpus grows.

## Shrinkage to the ratings prior

The penalised objective is

$$
\ell(\theta) - \tfrac{1}{2}\tau_\alpha \sum_i (\alpha_i - \alpha_i^0)^2
             - \tfrac{1}{2}\tau_\delta \sum_i (\delta_i - \delta_i^0)^2
$$

with $\alpha_i^0 = s\,(\text{attack}_i - \overline{\text{attack}})$ and
similarly for defence, $s = 0.03$ log-goals per rating point.

This is the load-bearing design decision. It:

1. **solves cold start** — a team with no matches has zero likelihood gradient,
   so its coefficients sit exactly on the prior;
2. **regularises small samples** — a team with three matches is pulled most of
   the way back, a team with forty is not, and the trade-off is handled by the
   arithmetic rather than by a hand-written rule;
3. **resolves the identifiability degeneracy** — adding a constant to every
   attack and every defence leaves all rates unchanged, so the likelihood alone
   has a flat direction. The prior pins it down.

## Optimisation

Adam over analytic gradients, 1200 iterations, learning rate 0.05, in NumPy.
$\rho$ is parameterised as $\rho = b \tanh(u)$ so it cannot leave the range
where $\tau$ stays positive.

A hand-rolled optimiser rather than `scipy.optimize` because the gradients are
worth writing down — the derivation is the part of the model that would be
asked about.

## Features

| feature | source |
| --- | --- |
| `elo_diff`, `elo_expectancy` | weighted Elo, pre-match |
| `rating_overall_diff`, `midfield_diff` | EA FC 25 |
| `home_att_vs_away_def`, `away_att_vs_home_def` | EA FC 25, crossed |
| `form_ppg_diff`, `form_gd_diff`, `form_gf_diff` | rolling 5 matches |
| `experience_diff` | log matches played |
| `rest_days_diff` | days since previous fixture |
| `neutral`, `knockout`, `same_confederation` | fixture context |
| `dc_logit_home`, `dc_logit_away`, `dc_draw_prob` | Dixon-Coles, stacked |
| `dc_xg_diff`, `dc_xg_total` | Dixon-Coles rates |

## Hyperparameters, and what is wrong with them

| parameter | value | why |
| --- | --- | --- |
| Elo `k_factor` | 40 | standard for international football |
| Elo `home_advantage` | 65 pts | ≈ the usual home edge |
| DC `half_life_days` | 1460 | one World Cup cycle |
| DC `ridge_attack/defence` | 6.0 | chosen so a team with ~10 matches sits roughly halfway to its prior |
| Logistic `C` | 0.25 | heavy shrinkage; 19 features on a few hundred rows |
| `class_weight` | `None` | see below |

**The honest caveat.** `C` was chosen by looking at the same walk-forward table
the README reports. That is mild selection bias: the reported out-of-sample
score is optimistic by an unknown but non-zero amount. The correct fix is
nested cross-validation — an inner walk-forward for selection inside an outer
one for reporting — and it is first on the roadmap. It is disclosed here rather
than buried because a reviewer will ask, and "we tuned on the test set" is a
much worse answer when it is discovered than when it is volunteered.

## Class imbalance

Draws are roughly 22% of outcomes. `class_weight="balanced"` lifts draw recall
and nudges accuracy up, but it distorts the probability scale, which is the
thing the model is actually for. The training report ships the comparison
(`/api/model/calibration` → `variants`) rather than asserting a winner, and the
default is off. Calibration does the job better: a Platt layer fitted over a
time-series split corrects the scale without discarding the likelihood's view
of how often draws happen.

## Knockout ties

A knockout tie does not end in a draw. Regulation probabilities are carried
into 30 minutes of extra time, modelled as $\lambda/3 \times 0.85$ — a third of
the time, discounted for how cautiously extra time is played. A remaining draw
goes to penalties, priced at 0.5 nudged by at most ±0.06 on the rating
difference. Shoot-outs are close to random, and pretending otherwise would be
the easiest place in the whole model to invent skill that is not there.

## References

- Dixon, M. J. & Coles, S. G. (1997). *Modelling Association Football Scores and
  Inefficiencies in the Football Betting Market.* JRSS-C 46(2).
- Constantinou, A. & Fenton, N. (2012). *Solving the Problem of Inadequate
  Scoring Rules for Assessing Probabilistic Football Forecast Models.* JQAS 8(1).
- Hvattum, L. M. & Arntzen, H. (2010). *Using ELO ratings for match result
  prediction in association football.* IJF 26(3).
