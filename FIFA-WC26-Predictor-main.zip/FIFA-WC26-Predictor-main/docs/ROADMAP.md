# Roadmap

Ordered by how much each item improves the *forecast*, not how impressive it
sounds.

## 1. Nested cross-validation for hyperparameter selection

The current `C` was chosen by looking at the reported walk-forward table, which
makes that table optimistic. Wrap an inner expanding-window selection loop
inside the outer evaluation loop so the reported score is untouched by
selection. Until this lands, the README's numbers carry an asterisk — see
`docs/MODEL.md`.

**Why first:** it is the only item here that changes whether the existing
numbers can be believed.

## 2. Expand the corpus

`make data` already pulls ~48,000 international matches. Train on them, retune
the Elo K factor and Dixon-Coles half-life against the larger sample, and
re-check whether the stack's edge over Elo-only widens. With 320 matches the
classifier is shrinkage-dominated; with 40,000 it is not.

## 3. Score the 2026 tournament

`scripts/evaluate.py` takes any CSV of played matches and returns log loss,
Brier, RPS and a calibration table against realised results. Drop the actual
2026 results in and the project stops being a model that *claims* skill and
becomes one with a track record on matches it provably never saw. This is the
single highest-value addition for a quant conversation.

## 4. Tournament simulation

Monte Carlo the full bracket from the group stage: sample scorelines from the
fitted joint distribution, resolve groups on FIFA tie-break rules, propagate
through the knockout tree. Outputs P(win group), P(reach final), P(champion) —
and, more interestingly, the *distribution* of those, which shows how much of
the tournament is draw-luck rather than quality.

## 5. Odds comparison

Join historical closing odds, strip the overround, and compare the model
against the market on log loss and RPS. The market is the benchmark that
matters; beating uniform is table stakes. This also enables a Kelly-sized
paper-betting backtest with a proper equity curve and drawdown — the most
direct translation of this project into trading language.

## 6. Player-level ratings

Aggregate EA FC 25 *player* ratings into squad strength, weighted by likely
minutes, so injuries and call-ups move the forecast. The national-team ratings
used now are a lagging snapshot; a squad-derived rating is a live one.

## 7. Model improvements worth testing

- **Ordered logit / probit** instead of multinomial — outcomes are ordered, and
  the model currently ignores that even though RPS rewards it.
- **Hierarchical Bayes** (PyMC) for the goal model, giving credible intervals on
  every probability rather than point estimates. Replaces ad-hoc ridge shrinkage
  with a principled hyperprior.
- **Gradient boosting** on the same features as a capacity check. Expect it to
  lose on this sample size; worth knowing by how much.

## 8. Platform

- Redis cache for repeated fixture requests, keyed on artifact hash.
- Scheduled retraining on a results feed, with a champion/challenger gate that
  only promotes a new artifact if it beats the incumbent out-of-sample.
- Prediction logging, so calibration can be measured on live traffic rather
  than only on the backtest.

## 9. Mobile

The API is already the only contract, and `types/api.ts` is platform-agnostic.
A React Native / Expo client reuses the types and client wholesale; the
components are the only part that needs rewriting.
