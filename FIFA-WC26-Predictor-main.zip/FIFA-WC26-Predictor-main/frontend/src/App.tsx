import BackgroundParticles from "./components/BackgroundParticles";
import FeaturedMatches from "./components/FeaturedMatches";
import Footer from "./components/Footer";
import Hero from "./components/Hero";
import ModelCard from "./components/ModelCard";
import Nav from "./components/Nav";
import Predictor from "./components/Predictor";
import Rankings from "./components/Rankings";
import StatsBar from "./components/StatsBar";
import { api } from "./api/client";
import { useAsync } from "./hooks/useApi";

export default function App() {
  // Fetched once here and passed down, so the header counters and the model
  // card cannot disagree about what the current model is.
  const { data: metrics } = useAsync(() => api.modelMetrics());

  return (
    <>
      <BackgroundParticles />
      <Nav />
      <main className="relative z-10">
        <Hero />
        <StatsBar metrics={metrics} />
        <Predictor />
        <FeaturedMatches />
        <ModelCard />
        <Rankings />
      </main>
      <Footer />
    </>
  );
}
