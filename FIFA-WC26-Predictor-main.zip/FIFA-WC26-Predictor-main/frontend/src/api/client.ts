/**
 * Thin typed wrapper around fetch.
 *
 * Every call goes through one place so that error shape, timeouts and the base
 * URL are handled once rather than in each component. The backend returns a
 * consistent `{error, message, status}` body for every failure, which is
 * unwrapped here into a real Error with a usable message.
 */
import type {
  BatchPredictionResponse,
  ApiErrorBody,
  FeatureWeight,
  Fixture,
  ModelMetrics,
  Prediction,
  TeamsResponse,
} from "@/types/api";

const BASE_URL = import.meta.env.VITE_API_BASE_URL ?? "";
const TIMEOUT_MS = 20_000;

export class ApiError extends Error {
  readonly status: number;
  readonly details?: Record<string, unknown>;

  constructor(body: ApiErrorBody) {
    super(body.message || body.error);
    this.name = "ApiError";
    this.status = body.status;
    this.details = body.details;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const response = await fetch(`${BASE_URL}/api${path}`, {
      headers: { "Content-Type": "application/json" },
      signal: controller.signal,
      ...init,
    });

    if (!response.ok) {
      let body: ApiErrorBody;
      try {
        body = (await response.json()) as ApiErrorBody;
      } catch {
        body = {
          error: "NetworkError",
          message: `Request failed with status ${response.status}`,
          status: response.status,
        };
      }
      throw new ApiError(body);
    }
    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error("The request timed out. Is the backend running on :8000?");
    }
    throw new Error(
      "Could not reach the prediction API. Start it with `make backend` (or `python wsgi.py`).",
    );
  } finally {
    clearTimeout(timer);
  }
}

export interface PredictOptions {
  neutral?: boolean;
  knockout?: boolean;
}

export const api = {
  health: () => request<{ status: string }>("/health"),

  teams: () => request<TeamsResponse>("/teams"),

  fixtures: () => request<{ fixtures: Fixture[] }>("/fixtures"),

  predict: (homeTeam: string, awayTeam: string, options: PredictOptions = {}) =>
    request<Prediction>("/predict", {
      method: "POST",
      body: JSON.stringify({
        home_team: homeTeam,
        away_team: awayTeam,
        neutral: options.neutral ?? true,
        knockout: options.knockout ?? false,
      }),
    }),

  predictBatch: (fixtures: { home_team: string; away_team: string }[]) =>
    request<BatchPredictionResponse>("/predict/batch", {
      method: "POST",
      body: JSON.stringify({ fixtures }),
    }),

  scoreGrid: (homeTeam: string, awayTeam: string) =>
    request<{ home_team: string; away_team: string; grid: number[][] }>(
      "/predict/score-grid",
      {
        method: "POST",
        body: JSON.stringify({ home_team: homeTeam, away_team: awayTeam }),
      },
    ),

  modelMetrics: () => request<ModelMetrics>("/model/metrics"),

  modelFeatures: () => request<{ features: FeatureWeight[] }>("/model/features"),

  calibration: () =>
    request<{
      calibration: {
        bin: string;
        n: number;
        mean_predicted: number;
        observed_frequency: number;
        gap: number;
      }[];
      variants: { variant: string; log_loss?: number; rps?: number; accuracy?: number }[];
    }>("/model/calibration"),
};
