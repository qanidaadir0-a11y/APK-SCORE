import { useEffect, useState } from "react";
import Particles, { initParticlesEngine } from "@tsparticles/react";
import { loadSlim } from "@tsparticles/slim";

const COLOURS = ["#ffffff", "#facc15", "#dc2626", "#2563eb", "#16a34a"];

/**
 * The drifting dots from the original prototype, kept as the one piece of pure
 * decoration on the page. It fades out on scroll so it never competes with the
 * data below, and is skipped entirely for users who ask for reduced motion.
 */
export default function BackgroundParticles() {
  const [ready, setReady] = useState(false);
  const [opacity, setOpacity] = useState(1);
  const [enabled] = useState(
    () => !window.matchMedia("(prefers-reduced-motion: reduce)").matches,
  );

  useEffect(() => {
    if (!enabled) return;
    let cancelled = false;
    initParticlesEngine(async (engine) => {
      await loadSlim(engine);
    }).then(() => !cancelled && setReady(true));
    return () => {
      cancelled = true;
    };
  }, [enabled]);

  useEffect(() => {
    if (!enabled) return;
    const onScroll = () => {
      const fade = Math.max(0, 1 - window.scrollY / 420);
      setOpacity(fade);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [enabled]);

  if (!enabled || !ready) return null;

  return (
    <Particles
      id="tsparticles"
      options={{
        fullScreen: { enable: false },
        background: { color: "transparent" },
        detectRetina: true,
        fpsLimit: 60,
        particles: {
          number: { value: 60, density: { enable: true } },
          color: { value: COLOURS },
          shape: { type: "circle" },
          opacity: { value: { min: 0.2, max: 0.7 } },
          size: { value: { min: 1, max: 3.5 } },
          move: {
            enable: true,
            speed: 0.7,
            direction: "none",
            outModes: { default: "out" },
          },
        },
      }}
      style={{ opacity, transition: "opacity 300ms ease" }}
    />
  );
}
