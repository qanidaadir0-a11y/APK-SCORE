import { useEffect, useState } from "react";
import { CalendarDays, MapPin } from "lucide-react";
import { api } from "@/api/client";
import { useAsync } from "@/hooks/useApi";
import { pct } from "@/lib/format";
import type { Prediction } from "@/types/api";

export default function FeaturedMatches() {
  const { data, loading, error } = useAsync(() => api.fixtures());
  const [predictions, setPredictions] = useState<Record<number, Prediction>>({});

  const fixtures = data?.fixtures ?? [];

  useEffect(() => {
    if (fixtures.length === 0) return;
    let cancelled = false;
    // One batched round trip rather than N requests — the endpoint exists
    // precisely so this board does not hammer the API on load.
    api
      .predictBatch(
        fixtures.map((f) => ({ home_team: f.home_team, away_team: f.away_team })),
      )
      .then((response) => {
        if (cancelled) return;
        const next: Record<number, Prediction> = {};
        response.predictions.forEach((prediction, index) => {
          const fixture = fixtures[index];
          if (fixture) next[fixture.fixture_id] = prediction;
        });
        setPredictions(next);
      })
      .catch(() => undefined);
    return () => {
      cancelled = true;
    };
  }, [data]);

  return (
    <section id="fixtures" className="section scroll-mt-20 border-t border-white/5 py-20">
      <div className="text-center">
        <h2 className="text-3xl font-bold sm:text-5xl">
          Featured <span className="text-red-500">Matches</span>
        </h2>
        <p className="mx-auto mt-4 max-w-xl text-sm text-white/50">
          Priced straight from{" "}
          <code className="font-mono text-white/70">data/raw/wc26_fixtures.csv</code> —
          swap that file for the real draw and this board follows.
        </p>
      </div>

      {loading && <p className="mt-10 text-center text-sm text-white/40">Loading fixtures…</p>}
      {error && <p className="mt-10 text-center text-sm text-red-300">{error}</p>}

      <div className="mt-12 grid gap-5 md:grid-cols-2">
        {fixtures.map((fixture) => {
          const prediction = predictions[fixture.fixture_id];
          const p = prediction?.probabilities;
          return (
            <article
              key={fixture.fixture_id}
              className="glass-card p-6 transition hover:border-white/20"
            >
              <div className="flex items-center justify-between">
                <span className="stat-chip">{fixture.group}</span>
                {prediction && (
                  <span className="font-mono text-xs text-white/45">
                    xG {prediction.expected_goals.home.toFixed(2)} –{" "}
                    {prediction.expected_goals.away.toFixed(2)}
                  </span>
                )}
              </div>

              <div className="mt-5 flex items-center justify-between gap-3">
                <p className="flex-1 text-lg font-bold leading-tight">{fixture.home_team}</p>
                <span className="font-mono text-xs text-white/30">vs</span>
                <p className="flex-1 text-right text-lg font-bold leading-tight">
                  {fixture.away_team}
                </p>
              </div>

              {p ? (
                <>
                  <div className="mt-5 flex h-2 overflow-hidden rounded-full">
                    <span className="bg-gold-400" style={{ width: `${p.home_win * 100}%` }} />
                    <span className="bg-white/60" style={{ width: `${p.draw * 100}%` }} />
                    <span className="bg-blue-400" style={{ width: `${p.away_win * 100}%` }} />
                  </div>
                  <div className="mt-2 flex justify-between font-mono text-[11px] text-white/50">
                    <span>{pct(p.home_win)}</span>
                    <span className="text-white/35">D {pct(p.draw)}</span>
                    <span>{pct(p.away_win)}</span>
                  </div>
                </>
              ) : (
                <div className="mt-5 h-2 animate-pulse rounded-full bg-white/10" />
              )}

              <div className="mt-5 flex flex-wrap gap-x-4 gap-y-1 text-[11px] text-white/40">
                <span className="flex items-center gap-1.5">
                  <CalendarDays size={12} />
                  {fixture.date} · {fixture.kickoff_et} ET
                </span>
                <span className="flex items-center gap-1.5">
                  <MapPin size={12} />
                  {fixture.venue}, {fixture.city}
                </span>
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
