import { motion } from "framer-motion";

const LETTERS = [
  { char: "F", className: "from-gold-300 to-gold-600" },
  { char: "I", className: "from-red-400 to-red-600" },
  { char: "F", className: "from-blue-400 to-blue-600" },
  { char: "A", className: "from-green-400 to-green-600" },
];

const SIZES = {
  sm: "text-3xl",
  md: "text-5xl",
  lg: "text-6xl sm:text-7xl",
} as const;

export default function FifaLogo({ size = "lg" }: { size?: keyof typeof SIZES }) {
  return (
    <motion.div
      className="flex items-center justify-center gap-3"
      initial={{ opacity: 0, scale: 0.92 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, ease: "easeOut" }}
    >
      <div className="relative">
        <div
          aria-hidden
          className="absolute inset-0 rounded-full bg-gradient-to-r from-gold-400/40 via-red-500/20 to-blue-500/40 blur-2xl"
        />
        <div
          className={`relative font-black tracking-tighter ${SIZES[size]}`}
          aria-label="FIFA"
        >
          {LETTERS.map(({ char, className }, index) => (
            <span
              key={index}
              className={`bg-gradient-to-r ${className} bg-clip-text text-transparent`}
            >
              {char}
            </span>
          ))}
        </div>
      </div>

      <div className="flex flex-col items-start leading-none">
        <span className="text-[10px] font-bold uppercase tracking-[0.3em] text-white/80">
          World Cup
        </span>
        <span className="gold-text text-2xl font-black tracking-tight">2026</span>
        <span className="mt-1 flex gap-1" aria-hidden>
          <i className="h-1 w-4 rounded-full bg-red-500" />
          <i className="h-1 w-4 rounded-full bg-white" />
          <i className="h-1 w-4 rounded-full bg-blue-500" />
        </span>
      </div>
    </motion.div>
  );
}
