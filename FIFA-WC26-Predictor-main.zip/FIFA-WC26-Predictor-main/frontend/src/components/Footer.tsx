import { Github, Linkedin, Mail } from "lucide-react";

const LINKS = [
  { href: "https://github.com/jana18ro", label: "GitHub", icon: Github },
  {
    href: "https://www.linkedin.com/in/jana-robert-oragbon/",
    label: "LinkedIn",
    icon: Linkedin,
  },
  { href: "mailto:janarobert.o.21@gmail.com", label: "Email", icon: Mail },
];

export default function Footer() {
  return (
    <footer className="border-t border-white/5 py-16">
      <div className="section text-center">
        <p className="gold-text text-2xl font-black tracking-tight">FIFA 2026</p>
        <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-white/45">
          A forecasting project, not a betting product. Every probability here
          comes with the out-of-sample score that says how much to trust it.
        </p>

        <div className="mt-8 flex justify-center gap-3">
          {LINKS.map(({ href, label, icon: Icon }) => (
            <a
              key={label}
              href={href}
              target="_blank"
              rel="noreferrer"
              className="flex items-center gap-2 rounded-full border border-white/10 px-4 py-2 text-xs text-white/60 transition hover:border-white/25 hover:text-white"
            >
              <Icon size={14} />
              {label}
            </a>
          ))}
        </div>

        <p className="mt-10 text-[11px] text-white/25">
          Match data compiled from public FIFA World Cup records. Team ratings
          from EA SPORTS FC 25, used for analysis only; not affiliated with or
          endorsed by FIFA or EA.
        </p>
        <p className="mt-2 text-[11px] text-white/20">US · MX · CA</p>
      </div>
    </footer>
  );
}
