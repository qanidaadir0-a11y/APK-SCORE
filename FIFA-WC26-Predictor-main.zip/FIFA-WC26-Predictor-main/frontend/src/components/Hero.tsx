import { motion } from "framer-motion";
import { ArrowDown, LineChart } from "lucide-react";
import FifaLogo from "./FifaLogo";

export default function Hero() {
  return (
    <section
      id="top"
      className="relative flex min-h-[92vh] flex-col items-center justify-center px-5 pt-20 text-center"
    >
      <div
        aria-hidden
        className="pointer-events-none absolute -left-40 -top-40 h-[680px] w-[680px] rounded-full bg-gold-500/10 blur-[160px]"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-40 -right-40 h-[620px] w-[620px] rounded-full bg-blue-600/10 blur-[160px]"
      />

      <div className="relative z-10 max-w-3xl">
        <FifaLogo />

        <motion.p
          className="mt-10 text-[11px] tracking-[0.42em] text-white/40"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.15 }}
        >
          UNITED STATES &nbsp;•&nbsp; MEXICO &nbsp;•&nbsp; CANADA
        </motion.p>

        <motion.h1
          className="mt-5 text-5xl font-extrabold leading-[1.05] sm:text-7xl"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          Match <span className="gold-text">Predictor</span>
        </motion.h1>

        <motion.p
          className="mx-auto mt-6 max-w-xl text-base leading-relaxed text-white/55"
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          Calibrated win, draw and correct-score probabilities for every
          fixture — built from twenty years of World Cup results and EA FC 25
          national team ratings, and validated the way a trading signal is:
          walk-forward, against baselines it has to beat.
        </motion.p>

        <motion.div
          className="mt-10 flex flex-wrap items-center justify-center gap-3"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <a
            href="#predictor"
            className="soft-glow inline-flex items-center gap-2 rounded-full bg-gold-400 px-7 py-3 text-sm font-semibold text-black transition hover:bg-gold-300"
          >
            Start predicting
            <ArrowDown size={16} />
          </a>
          <a
            href="#model"
            className="inline-flex items-center gap-2 rounded-full border border-white/15 px-7 py-3 text-sm font-semibold text-white/80 transition hover:border-white/30 hover:bg-white/5"
          >
            <LineChart size={16} />
            How it scores
          </a>
        </motion.div>
      </div>
    </section>
  );
}
