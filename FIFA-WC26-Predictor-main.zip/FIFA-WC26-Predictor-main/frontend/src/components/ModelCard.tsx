import {
  Bar,
  BarChart,
  CartesianGrid,
  Cell,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { BookOpen } from "lucide-react";
import { api } from "@/api/client";
import { useAsync } from "@/hooks/useApi";
import type { MetricSummary } from "@/types/api";

const ROW_LABELS: Record<string, string> = {
  uniform: "Uniform (1/3 each)",
  class_prior: "Base rate",
  elo_only: "Elo only",
  dixon_coles_only: "Dixon-Coles only",
  stack: "Stacked model",
};

const ORDER = ["uniform", "class_prior", "elo_only", "dixon_coles_only", "stack"];

const AXIS = { stroke: "rgba(255,255,255,0.3)", fontSize: 11 };
const TOOLTIP = {
  contentStyle: {
    background: "#0b0b0d",
    border: "1px solid rgba(255,255,255,0.12)",
    borderRadius: 12,
    fontSize: 12,
  },
};

/**
 * The model card. Every portfolio project shows a prediction; far fewer show
 * whether the prediction is any good, which is the only thing a reviewer
 * actually wants to know.
 */
export default function ModelCard() {
  const metrics = useAsync(() => api.modelMetrics());
  const features = useAsync(() => api.modelFeatures());
  const calibration = useAsync(() => api.calibration());

  const oos = metrics.data?.out_of_sample;
  const rows: [string, MetricSummary][] = oos
    ? ORDER.filter((key) => oos[key]).map((key) => [key, oos[key]] as [string, MetricSummary])
    : [];

  const featureData = (features.data?.features ?? [])
    .slice(0, 10)
    .map((f) => ({ name: f.feature, value: Number(f.abs_mean) }));

  const calibrationData = (calibration.data?.calibration ?? []).map((row) => ({
    predicted: Number((row.mean_predicted * 100).toFixed(1)),
    observed: Number((row.observed_frequency * 100).toFixed(1)),
    n: row.n,
  }));

  return (
    <section id="model" className="section scroll-mt-20 border-t border-white/5 py-20">
      <div className="text-center">
        <h2 className="text-3xl font-bold sm:text-5xl">
          Does it actually <span className="gold-text">work?</span>
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-sm leading-relaxed text-white/50">
          Scored by expanding-window walk-forward validation: train on
          everything up to a point in time, predict the next block, roll
          forward, never look back. Lower is better on every column but
          accuracy.
        </p>
      </div>

      {metrics.error && (
        <p className="mt-10 text-center text-sm text-red-300">{metrics.error}</p>
      )}

      {rows.length > 0 && (
        <div className="glass-card mt-12 overflow-x-auto p-2 sm:p-6">
          <table className="w-full min-w-[620px] text-sm">
            <thead>
              <tr className="text-left text-[11px] uppercase tracking-wider text-white/40">
                <th className="px-3 py-3 font-semibold">Model</th>
                <th className="px-3 py-3 text-right font-semibold">Accuracy</th>
                <th className="px-3 py-3 text-right font-semibold">Log loss</th>
                <th className="px-3 py-3 text-right font-semibold">Brier</th>
                <th className="px-3 py-3 text-right font-semibold">RPS</th>
                <th className="px-3 py-3 text-right font-semibold">Calib. error</th>
              </tr>
            </thead>
            <tbody className="font-mono">
              {rows.map(([key, row]) => {
                const shipped = key === "stack";
                return (
                  <tr
                    key={key}
                    className={`border-t border-white/5 ${
                      shipped ? "bg-gold-400/[0.07] text-white" : "text-white/60"
                    }`}
                  >
                    <td className="px-3 py-3 font-sans">
                      {ROW_LABELS[key]}
                      {shipped && (
                        <span className="ml-2 rounded-full bg-gold-400/20 px-2 py-0.5 text-[10px] text-gold-300">
                          shipped
                        </span>
                      )}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {(row.accuracy * 100).toFixed(1)}%
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {row.log_loss.toFixed(4)}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">
                      {row.brier_score.toFixed(4)}
                    </td>
                    <td className="px-3 py-3 text-right tabular-nums">{row.rps.toFixed(4)}</td>
                    <td className="px-3 py-3 text-right tabular-nums">{row.ece.toFixed(4)}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {metrics.data && (
            <p className="px-3 pb-2 pt-4 text-[11px] text-white/35">
              {metrics.data.n_out_of_sample} out-of-sample matches ·{" "}
              {metrics.data.n_matches} matches in the corpus ({metrics.data.date_range[0]}{" "}
              to {metrics.data.date_range[1]}) · trained{" "}
              {new Date(metrics.data.trained_at).toLocaleString()}
            </p>
          )}
        </div>
      )}

      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        <div className="glass-card p-6">
          <h3 className="text-sm font-semibold text-white/80">Feature influence</h3>
          <p className="mt-1.5 text-[11px] text-white/40">
            Mean absolute logistic coefficient on standardised inputs, so the
            bars are directly comparable.
          </p>
          <div className="mt-5 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={featureData} layout="vertical" margin={{ left: 40, right: 12 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis type="number" {...AXIS} />
                <YAxis type="category" dataKey="name" width={130} {...AXIS} />
                <Tooltip {...TOOLTIP} cursor={{ fill: "rgba(255,255,255,0.04)" }} />
                <Bar dataKey="value" radius={[0, 4, 4, 0]}>
                  {featureData.map((entry, index) => (
                    <Cell key={entry.name} fill={index < 3 ? "#facc15" : "#6b7280"} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-6">
          <h3 className="text-sm font-semibold text-white/80">Reliability</h3>
          <p className="mt-1.5 text-[11px] text-white/40">
            Stated probability against realised frequency. A perfectly
            calibrated model sits on the dashed diagonal — when it says 30%, it
            happens 30% of the time.
          </p>
          <div className="mt-5 h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={calibrationData} margin={{ left: 0, right: 12 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.06)" />
                <XAxis
                  dataKey="predicted"
                  {...AXIS}
                  label={{
                    value: "predicted %",
                    position: "insideBottom",
                    offset: -4,
                    fill: "rgba(255,255,255,0.3)",
                    fontSize: 10,
                  }}
                />
                <YAxis {...AXIS} />
                <Tooltip {...TOOLTIP} />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="rgba(255,255,255,0.25)"
                  strokeDasharray="4 4"
                  dot={false}
                  name="perfect"
                />
                <Line
                  type="monotone"
                  dataKey="observed"
                  stroke="#facc15"
                  strokeWidth={2}
                  dot={{ r: 3, fill: "#facc15" }}
                  name="observed"
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {calibration.data?.variants && calibration.data.variants.length > 0 && (
        <div className="glass-card mt-6 p-6">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-white/80">
            <BookOpen size={15} className="text-gold-400" />
            Choices worth questioning
          </h3>
          <p className="mt-1.5 text-[11px] leading-relaxed text-white/40">
            Class re-weighting and probability calibration both sound like free
            wins. Measured on a proper scoring rule they are trade-offs, so the
            comparison is shipped rather than asserted.
          </p>
          <div className="mt-5 flex flex-wrap gap-3">
            {calibration.data.variants.map((variant) => (
              <div
                key={variant.variant}
                className="rounded-xl border border-white/10 bg-black/30 px-4 py-3"
              >
                <p className="font-mono text-xs text-white/70">{variant.variant}</p>
                <p className="mt-1 font-mono text-[11px] text-white/45">
                  log loss {variant.log_loss?.toFixed(4) ?? "—"} · RPS{" "}
                  {variant.rps?.toFixed(4) ?? "—"}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </section>
  );
}
