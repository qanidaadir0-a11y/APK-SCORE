import { useEffect, useState } from "react";

const LINKS = [
  { href: "#predictor", label: "Predictor" },
  { href: "#fixtures", label: "Fixtures" },
  { href: "#model", label: "Model" },
  { href: "#rankings", label: "Rankings" },
];

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-colors duration-300 ${
        scrolled ? "border-b border-white/10 bg-black/70 backdrop-blur-xl" : "bg-transparent"
      }`}
    >
      <nav className="section flex h-14 items-center justify-between">
        <a href="#top" className="text-sm font-bold tracking-[0.2em] text-white/90">
          WC<span className="gold-text">26</span>
        </a>
        <ul className="flex items-center gap-5 text-sm text-white/60">
          {LINKS.map((link) => (
            <li key={link.href}>
              <a className="transition hover:text-white" href={link.href}>
                {link.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
