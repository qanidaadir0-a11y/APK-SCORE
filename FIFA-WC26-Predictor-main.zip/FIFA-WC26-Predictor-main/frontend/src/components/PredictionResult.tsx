import { motion } from "framer-motion";
import { Activity, Gauge, ShieldHalf, Swords, Trophy } from "lucide-react";
import ProbabilityBar from "./ProbabilityBar";
import ScoreGrid from "./ScoreGrid";
import { confidenceLabel, outcomeLabel, pct, signed } from "@/lib/format";
import type { Prediction } from "@/types/api";

interface Props {
  prediction: Prediction;
  grid: number[][] | null;
}

function Metric({
  label,
  value,
  hint,
}: {
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <div className="rounded-2xl border border-white/10 bg-black/30 p-4">
      <p className="label">{label}</p>
      <p className="mt-1.5 font-mono text-xl font-semibold">{value}</p>
      {hint && <p className="mt-1 text-[11px] text-white/40">{hint}</p>}
    </div>
  );
}

export default function PredictionResult({ prediction, grid }: Props) {
  const { fixture, probabilities, expected_goals, scorelines, markets, model_inputs } =
    prediction;
  const home = fixture.home_team;
  const away = fixture.away_team;

  const segments = [
    {
      key: "home_win",
      label: `${home}`,
      value: probabilities.home_win,
      className: "bg-gold-400",
    },
    { key: "draw", label: "Draw", value: probabilities.draw, className: "bg-white/70" },
    {
      key: "away_win",
      label: `${away}`,
      value: probabilities.away_win,
      className: "bg-blue-400",
    },
  ];

  return (
    <motion.div
      className="mt-10 space-y-6"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35 }}
    >
      {/* headline ------------------------------------------------------- */}
      <div className="glass-card p-6 sm:p-8">
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="label">Most likely outcome</p>
            <p className="mt-1 text-2xl font-bold">
              {outcomeLabel(prediction.most_likely_outcome, home, away)}
              <span className="gold-text ml-3 font-mono text-xl">
                {prediction.predicted_scoreline.home}–{prediction.predicted_scoreline.away}
              </span>
            </p>
          </div>
          <span className="stat-chip flex items-center gap-1.5">
            <Gauge size={13} />
            {confidenceLabel(prediction.confidence)}
          </span>
        </div>

        <ProbabilityBar segments={segments} />

        <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Metric
            label="Expected goals"
            value={`${expected_goals.home.toFixed(2)} – ${expected_goals.away.toFixed(2)}`}
            hint={`${expected_goals.total.toFixed(2)} total`}
          />
          <Metric
            label="Elo difference"
            value={signed(model_inputs.elo.diff, 0)}
            hint={`${Math.round(model_inputs.elo.home)} v ${Math.round(model_inputs.elo.away)}`}
          />
          <Metric
            label="Rating edge"
            value={signed(
              model_inputs.ratings.home.overall - model_inputs.ratings.away.overall,
              0,
            )}
            hint={`${model_inputs.ratings.home.overall} v ${model_inputs.ratings.away.overall} OVR`}
          />
          <Metric
            label="Over 2.5 goals"
            value={pct(markets.over_2_5_goals, 1)}
            hint={`BTTS ${pct(markets.both_teams_to_score, 1)}`}
          />
        </div>
      </div>

      {/* knockout branch ------------------------------------------------- */}
      {prediction.knockout && (
        <div className="glass-card p-6 sm:p-8">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-white/80">
            <Trophy size={15} className="text-gold-400" />
            Knockout tie — who goes through
          </h3>
          <p className="mt-2 text-xs leading-relaxed text-white/45">
            A draw after ninety minutes does not end a knockout tie, so the
            regulation probabilities are carried through thirty minutes of extra
            time and, failing that, a shoot-out priced close to a coin flip.
          </p>
          <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <Metric label={`${home} advance`} value={pct(prediction.knockout.advance_home, 1)} />
            <Metric label={`${away} advance`} value={pct(prediction.knockout.advance_away, 1)} />
            <Metric
              label="Reaches extra time"
              value={pct(prediction.knockout.reaches_extra_time, 1)}
            />
            <Metric
              label="Reaches penalties"
              value={pct(prediction.knockout.reaches_penalties, 1)}
            />
          </div>
        </div>
      )}

      {/* scorelines + grid ------------------------------------------------ */}
      <div className="grid gap-6 lg:grid-cols-5">
        <div className="glass-card p-6 lg:col-span-2">
          <h3 className="flex items-center gap-2 text-sm font-semibold text-white/80">
            <Swords size={15} className="text-gold-400" />
            Most likely scorelines
          </h3>
          <ul className="mt-5 space-y-2.5">
            {scorelines.map((line) => (
              <li key={`${line.home}-${line.away}`} className="flex items-center gap-3">
                <span className="w-14 font-mono text-sm font-semibold">
                  {line.home}–{line.away}
                </span>
                <span className="h-2 flex-1 overflow-hidden rounded-full bg-white/[0.07]">
                  <span
                    className="block h-full rounded-full bg-gold-400/80"
                    style={{
                      width: `${(line.probability / scorelines[0].probability) * 100}%`,
                    }}
                  />
                </span>
                <span className="w-12 text-right font-mono text-xs text-white/55">
                  {pct(line.probability, 1)}
                </span>
              </li>
            ))}
          </ul>
        </div>

        <div className="glass-card p-6 lg:col-span-3">
          {grid ? (
            <ScoreGrid homeTeam={home} awayTeam={away} grid={grid} />
          ) : (
            <p className="text-sm text-white/40">Loading the scoreline distribution…</p>
          )}
        </div>
      </div>

      {/* inputs ----------------------------------------------------------- */}
      <div className="glass-card p-6 sm:p-8">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white/80">
          <Activity size={15} className="text-gold-400" />
          What went into this
        </h3>
        <div className="mt-5 grid gap-6 sm:grid-cols-2">
          {([
            ["home", home] as const,
            ["away", away] as const,
          ]).map(([side, name]) => {
            const rating = model_inputs.ratings[side];
            const form = model_inputs.form[side];
            return (
              <div key={side} className="rounded-2xl border border-white/10 bg-black/30 p-5">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <ShieldHalf size={14} className="text-white/40" />
                  {name}
                  {!rating.known && (
                    <span className="stat-chip !text-[10px]">unrated · replacement level</span>
                  )}
                </p>
                <dl className="mt-4 grid grid-cols-2 gap-x-4 gap-y-2 font-mono text-xs text-white/60">
                  <dt className="text-white/35">Overall</dt>
                  <dd className="text-right">{rating.overall}</dd>
                  <dt className="text-white/35">Attack</dt>
                  <dd className="text-right">{rating.attack}</dd>
                  <dt className="text-white/35">Midfield</dt>
                  <dd className="text-right">{rating.midfield}</dd>
                  <dt className="text-white/35">Defence</dt>
                  <dd className="text-right">{rating.defence}</dd>
                  <dt className="text-white/35">Form (pts/game)</dt>
                  <dd className="text-right">{form.ppg.toFixed(2)}</dd>
                  <dt className="text-white/35">Form (goal diff)</dt>
                  <dd className="text-right">{signed(form.gd, 2)}</dd>
                  <dt className="text-white/35">Matches in corpus</dt>
                  <dd className="text-right">{form.played}</dd>
                </dl>
              </div>
            );
          })}
        </div>
        <p className="mt-5 text-[11px] leading-relaxed text-white/35">
          The goal model alone makes it{" "}
          <span className="font-mono text-white/60">
            {pct(model_inputs.dixon_coles_only.home_win, 1)} /{" "}
            {pct(model_inputs.dixon_coles_only.draw, 1)} /{" "}
            {pct(model_inputs.dixon_coles_only.away_win, 1)}
          </span>
          . The figures above are what the stacked classifier makes of that once
          Elo, recent form and the ratings are added.
        </p>
      </div>
    </motion.div>
  );
}
