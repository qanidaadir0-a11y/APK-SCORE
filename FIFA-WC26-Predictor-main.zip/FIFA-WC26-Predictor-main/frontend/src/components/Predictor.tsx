import { useCallback, useEffect, useState } from "react";
import { AlertTriangle, Loader2, Repeat2, Sparkles } from "lucide-react";
import { api } from "@/api/client";
import { useAction, useAsync } from "@/hooks/useApi";
import PredictionResult from "./PredictionResult";
import TeamSelect from "./TeamSelect";

export default function Predictor() {
  const { data: teamsData, loading: teamsLoading, error: teamsError } = useAsync(
    () => api.teams(),
  );
  const [home, setHome] = useState("");
  const [away, setAway] = useState("");
  const [knockout, setKnockout] = useState(false);
  const [neutral, setNeutral] = useState(true);
  const [grid, setGrid] = useState<number[][] | null>(null);

  const predict = useAction(api.predict);
  const teams = teamsData?.teams ?? [];

  const run = useCallback(async () => {
    if (!home || !away) return;
    setGrid(null);
    const result = await predict.run(home, away, { neutral, knockout });
    if (result) {
      api
        .scoreGrid(home, away)
        .then((response) => setGrid(response.grid))
        .catch(() => setGrid(null));
    }
  }, [home, away, neutral, knockout, predict]);

  // Keep the displayed prediction honest: if the inputs change, the old result
  // no longer describes what is on screen, so it goes.
  useEffect(() => {
    predict.reset();
    setGrid(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [home, away, neutral, knockout]);

  const swap = () => {
    setHome(away);
    setAway(home);
  };

  const ready = Boolean(home && away && home !== away);

  return (
    <section id="predictor" className="section scroll-mt-20 border-t border-white/5 py-20">
      <div className="glass-card soft-glow p-6 sm:p-10">
        <div className="text-center">
          <h2 className="text-3xl font-bold sm:text-5xl">
            The <span className="gold-text">Match Predictor</span>
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-sm leading-relaxed text-white/50">
            Pick any two nations. Every number below is produced by the model —
            nothing on this page is hard-coded.
          </p>
        </div>

        {teamsError && (
          <div className="mt-8 flex items-start gap-3 rounded-2xl border border-red-500/30 bg-red-500/10 p-4 text-sm text-red-200">
            <AlertTriangle size={18} className="mt-0.5 shrink-0" />
            <div>
              <p className="font-semibold">Could not load the team list</p>
              <p className="mt-1 text-red-200/70">{teamsError}</p>
            </div>
          </div>
        )}

        <div className="mt-10 grid items-end gap-5 md:grid-cols-[1fr_auto_1fr]">
          <TeamSelect
            id="home-team"
            label="Home team"
            teams={teams}
            value={home}
            exclude={away}
            disabled={teamsLoading}
            onChange={setHome}
          />
          <button
            type="button"
            onClick={swap}
            disabled={!home && !away}
            aria-label="Swap teams"
            className="mx-auto mb-1 hidden h-11 w-11 items-center justify-center rounded-full border border-white/10 text-white/50 transition hover:border-white/25 hover:text-white disabled:opacity-30 md:flex"
          >
            <Repeat2 size={17} />
          </button>
          <TeamSelect
            id="away-team"
            label="Away team"
            teams={teams}
            value={away}
            exclude={home}
            disabled={teamsLoading}
            onChange={setAway}
          />
        </div>

        <div className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-3 text-sm text-white/60">
          <label className="flex cursor-pointer items-center gap-2.5">
            <input
              type="checkbox"
              checked={knockout}
              onChange={(event) => setKnockout(event.target.checked)}
              className="h-4 w-4 accent-gold-400"
            />
            Knockout tie <span className="text-white/35">(extra time + penalties)</span>
          </label>
          <label className="flex cursor-pointer items-center gap-2.5">
            <input
              type="checkbox"
              checked={!neutral}
              onChange={(event) => setNeutral(!event.target.checked)}
              className="h-4 w-4 accent-gold-400"
            />
            True home advantage <span className="text-white/35">(host nation)</span>
          </label>
        </div>

        <button
          type="button"
          onClick={run}
          disabled={!ready || predict.loading}
          className="soft-glow mt-8 flex w-full items-center justify-center gap-2 rounded-full bg-gold-400 py-4 text-sm font-semibold text-black transition hover:bg-gold-300 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {predict.loading ? (
            <>
              <Loader2 size={16} className="animate-spin" />
              Running the model…
            </>
          ) : (
            <>
              <Sparkles size={16} />
              Generate prediction
            </>
          )}
        </button>

        {predict.error && (
          <p className="mt-4 text-center text-sm text-red-300">{predict.error}</p>
        )}
      </div>

      {predict.data && <PredictionResult prediction={predict.data} grid={grid} />}
    </section>
  );
}
