import { motion } from "framer-motion";
import { pct } from "@/lib/format";

interface Segment {
  key: string;
  label: string;
  value: number;
  className: string;
}

/**
 * One stacked bar rather than three separate ones. A three-way market is a
 * partition of certainty, and a single bar shows that: the eye reads the
 * relative widths, which is the actual question being asked.
 */
export default function ProbabilityBar({ segments }: { segments: Segment[] }) {
  return (
    <div>
      <div
        className="flex h-11 w-full overflow-hidden rounded-xl border border-white/10"
        role="img"
        aria-label={segments
          .map((s) => `${s.label} ${pct(s.value, 1)}`)
          .join(", ")}
      >
        {segments.map((segment) => (
          <motion.div
            key={segment.key}
            className={`flex items-center justify-center ${segment.className}`}
            initial={{ width: 0 }}
            animate={{ width: `${Math.max(segment.value * 100, 0)}%` }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          >
            {segment.value > 0.09 && (
              <span className="font-mono text-xs font-semibold text-black/80">
                {pct(segment.value)}
              </span>
            )}
          </motion.div>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap justify-between gap-x-4 gap-y-1 text-xs text-white/50">
        {segments.map((segment) => (
          <span key={segment.key} className="flex items-center gap-2">
            <i className={`h-2 w-2 rounded-full ${segment.className}`} />
            {segment.label}
            <span className="font-mono text-white/80">{pct(segment.value, 1)}</span>
          </span>
        ))}
      </div>
    </div>
  );
}
