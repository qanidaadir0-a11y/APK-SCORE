import { useState } from "react";
import { api } from "@/api/client";
import { useAsync } from "@/hooks/useApi";

const CONFEDERATIONS = ["All", "UEFA", "CONMEBOL", "CONCACAF", "CAF", "AFC", "OFC"];

export default function Rankings() {
  const { data, loading, error } = useAsync(() => api.teams());
  const [filter, setFilter] = useState("All");

  const teams = (data?.teams ?? [])
    .filter((team) => filter === "All" || team.confederation === filter)
    .slice(0, 20);

  return (
    <section id="rankings" className="section scroll-mt-20 border-t border-white/5 py-20">
      <div className="flex flex-wrap items-end justify-between gap-5">
        <div>
          <h2 className="text-3xl font-bold sm:text-4xl">
            Model <span className="gold-text">rankings</span>
          </h2>
          <p className="mt-3 max-w-lg text-sm text-white/50">
            Elo after the last match in the corpus, seeded from EA FC 25 ratings
            so teams with little recorded history still start somewhere sensible.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {CONFEDERATIONS.map((confederation) => (
            <button
              key={confederation}
              type="button"
              onClick={() => setFilter(confederation)}
              className={`rounded-full border px-3.5 py-1.5 text-xs transition ${
                filter === confederation
                  ? "border-gold-400/50 bg-gold-400/15 text-gold-300"
                  : "border-white/10 text-white/50 hover:border-white/25 hover:text-white"
              }`}
            >
              {confederation}
            </button>
          ))}
        </div>
      </div>

      {loading && <p className="mt-10 text-sm text-white/40">Loading rankings…</p>}
      {error && <p className="mt-10 text-sm text-red-300">{error}</p>}

      <div className="glass-card mt-10 overflow-x-auto">
        <table className="w-full min-w-[560px] text-sm">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wider text-white/40">
              <th className="px-5 py-4 font-semibold">#</th>
              <th className="px-5 py-4 font-semibold">Team</th>
              <th className="px-5 py-4 text-right font-semibold">Elo</th>
              <th className="px-5 py-4 text-right font-semibold">OVR</th>
              <th className="px-5 py-4 text-right font-semibold">ATT</th>
              <th className="px-5 py-4 text-right font-semibold">MID</th>
              <th className="px-5 py-4 text-right font-semibold">DEF</th>
            </tr>
          </thead>
          <tbody className="font-mono">
            {teams.map((team, index) => (
              <tr key={team.name} className="border-t border-white/5">
                <td className="px-5 py-3 text-white/35">{index + 1}</td>
                <td className="px-5 py-3 font-sans font-medium">
                  {team.name}
                  <span className="ml-2 text-[11px] text-white/30">{team.confederation}</span>
                </td>
                <td className="px-5 py-3 text-right tabular-nums text-gold-300">
                  {Math.round(team.elo)}
                </td>
                <td className="px-5 py-3 text-right tabular-nums text-white/70">
                  {team.overall}
                </td>
                <td className="px-5 py-3 text-right tabular-nums text-white/50">
                  {team.attack}
                </td>
                <td className="px-5 py-3 text-right tabular-nums text-white/50">
                  {team.midfield}
                </td>
                <td className="px-5 py-3 text-right tabular-nums text-white/50">
                  {team.defence}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
