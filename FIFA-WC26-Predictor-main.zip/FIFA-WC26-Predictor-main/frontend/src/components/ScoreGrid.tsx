import { pct } from "@/lib/format";

interface Props {
  homeTeam: string;
  awayTeam: string;
  grid: number[][];
}

/**
 * The joint scoreline distribution as a heat map.
 *
 * This is the part of the model most people have never seen: the win/draw/loss
 * split is just this table folded along its diagonal. Showing it makes the
 * point that the model predicts a *distribution*, not a result.
 */
export default function ScoreGrid({ homeTeam, awayTeam, grid }: Props) {
  const max = Math.max(...grid.flat());

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[420px] border-separate border-spacing-1 text-center font-mono text-[11px]">
        <caption className="mb-3 text-left text-xs text-white/45">
          P(exact scoreline) — rows: {homeTeam} goals, columns: {awayTeam} goals
        </caption>
        <thead>
          <tr>
            <th scope="col" className="w-8" />
            {grid[0].map((_, away) => (
              <th key={away} scope="col" className="pb-1 font-semibold text-white/40">
                {away}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {grid.map((row, home) => (
            <tr key={home}>
              <th scope="row" className="pr-1 font-semibold text-white/40">
                {home}
              </th>
              {row.map((probability, away) => {
                const intensity = max > 0 ? probability / max : 0;
                const isDraw = home === away;
                return (
                  <td
                    key={away}
                    title={`${homeTeam} ${home}-${away} ${awayTeam}: ${pct(probability, 2)}`}
                    className={`rounded px-1.5 py-2 tabular-nums transition ${
                      isDraw ? "ring-1 ring-inset ring-white/15" : ""
                    }`}
                    style={{
                      backgroundColor: `rgba(250, 204, 21, ${(intensity * 0.85).toFixed(3)})`,
                      color: intensity > 0.45 ? "#0a0a0a" : "rgba(255,255,255,0.65)",
                    }}
                  >
                    {(probability * 100).toFixed(1)}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
