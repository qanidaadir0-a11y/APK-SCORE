import { Database, Globe, Sigma, Target } from "lucide-react";
import type { ModelMetrics } from "@/types/api";

interface Props {
  metrics: ModelMetrics | null;
}

/**
 * The counters from the prototype, repointed at numbers the model actually
 * produces. "48 nations" is a fact about the tournament; "log loss 1.00" is a
 * fact about this model, and the second is the one worth showing.
 */
export default function StatsBar({ metrics }: Props) {
  const stack = metrics?.out_of_sample?.stack;

  const items = [
    {
      icon: Globe,
      value: metrics ? String(metrics.n_teams) : "—",
      label: "Teams priced",
      tint: "bg-blue-500/15 text-blue-300",
    },
    {
      icon: Database,
      value: metrics ? metrics.n_matches.toLocaleString() : "—",
      label: "Matches trained on",
      tint: "bg-gold-400/15 text-gold-300",
    },
    {
      icon: Target,
      value: stack ? stack.log_loss.toFixed(3) : "—",
      label: "Out-of-sample log loss",
      tint: "bg-green-500/15 text-green-300",
    },
    {
      icon: Sigma,
      value: stack ? stack.rps.toFixed(3) : "—",
      label: "Ranked probability score",
      tint: "bg-red-500/15 text-red-300",
    },
  ];

  return (
    <section className="section border-t border-white/5 py-16">
      <div className="grid grid-cols-2 gap-8 md:grid-cols-4">
        {items.map(({ icon: Icon, value, label, tint }) => (
          <div key={label} className="text-center">
            <div
              className={`mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-2xl ${tint}`}
            >
              <Icon size={22} />
            </div>
            <p className="font-mono text-3xl font-bold sm:text-4xl">{value}</p>
            <p className="mt-2 text-xs text-white/45">{label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
