import type { Team } from "@/types/api";

interface Props {
  id: string;
  label: string;
  teams: Team[];
  value: string;
  exclude?: string;
  disabled?: boolean;
  onChange: (value: string) => void;
}

/**
 * A native <select>, grouped by confederation. Native is the right call here:
 * it is keyboard accessible and screen-reader correct for free, and on a phone
 * it opens the OS picker — which matters, because this is the control the
 * whole page exists for.
 */
export default function TeamSelect({
  id,
  label,
  teams,
  value,
  exclude,
  disabled,
  onChange,
}: Props) {
  const grouped = teams.reduce<Record<string, Team[]>>((acc, team) => {
    const key = team.confederation || "Other";
    (acc[key] ??= []).push(team);
    return acc;
  }, {});

  return (
    <div className="flex flex-col gap-2">
      <label htmlFor={id} className="label">
        {label}
      </label>
      <select
        id={id}
        value={value}
        disabled={disabled}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-xl border border-white/10 bg-black/60 px-4 py-3.5 text-sm text-white transition focus:border-gold-400/60 focus:outline-none focus:ring-2 focus:ring-gold-400/30 disabled:opacity-50"
      >
        <option value="">Choose a team…</option>
        {Object.entries(grouped)
          .sort(([a], [b]) => a.localeCompare(b))
          .map(([confederation, list]) => (
            <optgroup key={confederation} label={confederation}>
              {list
                .slice()
                .sort((a, b) => a.name.localeCompare(b.name))
                .map((team) => (
                  <option
                    key={team.name}
                    value={team.name}
                    disabled={team.name === exclude}
                  >
                    {team.name} · {team.overall} OVR · {Math.round(team.elo)} Elo
                  </option>
                ))}
            </optgroup>
          ))}
      </select>
    </div>
  );
}
