import { useCallback, useEffect, useRef, useState } from "react";
import type { DependencyList } from "react";

interface AsyncState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

/** Fetch once on mount, with the usual loading/error triad and unmount safety. */
export function useAsync<T>(
  loader: () => Promise<T>,
  deps: DependencyList = [],
): AsyncState<T> & { reload: () => void } {
  const [state, setState] = useState<AsyncState<T>>({
    data: null,
    loading: true,
    error: null,
  });
  const [nonce, setNonce] = useState(0);
  const alive = useRef(true);

  useEffect(() => {
    alive.current = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    loader()
      .then((data) => alive.current && setState({ data, loading: false, error: null }))
      .catch(
        (error: Error) =>
          alive.current &&
          setState({ data: null, loading: false, error: error.message }),
      );
    return () => {
      alive.current = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [...deps, nonce]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { ...state, reload };
}

/** Same triad, but fired by a user action rather than on mount. */
export function useAction<Args extends unknown[], T>(
  action: (...args: Args) => Promise<T>,
) {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const requestId = useRef(0);

  const run = useCallback(
    async (...args: Args) => {
      const id = ++requestId.current;
      setLoading(true);
      setError(null);
      try {
        const result = await action(...args);
        // Ignore a slow response that a newer request has already superseded.
        if (id === requestId.current) setData(result);
        return result;
      } catch (err) {
        if (id === requestId.current) setError((err as Error).message);
        return null;
      } finally {
        if (id === requestId.current) setLoading(false);
      }
    },
    [action],
  );

  const reset = useCallback(() => {
    requestId.current++;
    setData(null);
    setError(null);
    setLoading(false);
  }, []);

  return { data, loading, error, run, reset };
}
