export const pct = (value: number, digits = 0): string =>
  `${(value * 100).toFixed(digits)}%`;

export const signed = (value: number, digits = 0): string =>
  `${value > 0 ? "+" : ""}${value.toFixed(digits)}`;

export const outcomeLabel = (
  key: string,
  home: string,
  away: string,
): string => {
  if (key === "home_win") return `${home} win`;
  if (key === "away_win") return `${away} win`;
  return "Draw";
};

/** Shannon entropy of the 3-way market, normalised to [0, 1]. */
export const marketEntropy = (probabilities: number[]): number => {
  const sum = probabilities.reduce(
    (acc, p) => acc + (p > 0 ? -p * Math.log(p) : 0),
    0,
  );
  return sum / Math.log(probabilities.length);
};

export const confidenceLabel = (confidence: number): string => {
  if (confidence >= 0.35) return "Strong edge";
  if (confidence >= 0.18) return "Clear lean";
  if (confidence >= 0.07) return "Slight lean";
  return "Coin flip";
};
