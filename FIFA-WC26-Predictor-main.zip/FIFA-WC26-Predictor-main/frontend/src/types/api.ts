/**
 * Mirrors the Flask API's JSON contract.
 *
 * Kept in one file on purpose: when the backend's response shape changes, the
 * TypeScript compiler points at every component that has to change with it.
 */

export type OutcomeKey = "home_win" | "draw" | "away_win";

export interface Team {
  name: string;
  code: string;
  confederation: string;
  overall: number;
  attack: number;
  midfield: number;
  defence: number;
  rated: boolean;
  elo: number;
  matches_in_corpus: number;
}

export interface TeamsResponse {
  count: number;
  teams: Team[];
}

export interface Scoreline {
  home: number;
  away: number;
  probability: number;
}

export interface RatingVector {
  team: string;
  overall: number;
  attack: number;
  midfield: number;
  defence: number;
  confederation: string;
  fifa_code: string;
  known: boolean;
}

export interface FormSnapshot {
  ppg: number;
  gf: number;
  ga: number;
  gd: number;
  played: number;
}

export interface KnockoutBranch {
  reaches_extra_time: number;
  reaches_penalties: number;
  extra_time: Record<OutcomeKey, number>;
  penalty_edge_home: number;
  advance_home: number;
  advance_away: number;
}

export interface Prediction {
  schema_version: string;
  fixture: {
    home_team: string;
    away_team: string;
    neutral: boolean;
    knockout: boolean;
  };
  probabilities: Record<OutcomeKey, number>;
  most_likely_outcome: OutcomeKey;
  confidence: number;
  expected_goals: { home: number; away: number; total: number };
  scorelines: Scoreline[];
  predicted_scoreline: { home: number; away: number };
  markets: {
    both_teams_to_score: number;
    over_2_5_goals: number;
    home_clean_sheet: number;
    away_clean_sheet: number;
  };
  model_inputs: {
    elo: { home: number; away: number; diff: number };
    ratings: { home: RatingVector; away: RatingVector };
    form: { home: FormSnapshot; away: FormSnapshot };
    dixon_coles_only: Record<OutcomeKey, number>;
  };
  features: Record<string, number>;
  knockout?: KnockoutBranch;
}

export interface BatchPredictionResponse {
  count: number;
  predictions: Prediction[];
}

export interface MetricSummary {
  label: string;
  n: number;
  accuracy: number;
  log_loss: number;
  brier_score: number;
  rps: number;
  ece: number;
}

export interface ModelMetrics {
  trained_at: string;
  n_matches: number;
  n_training_rows: number;
  n_teams: number;
  date_range: [string, string];
  out_of_sample: Record<string, MetricSummary>;
  n_out_of_sample: number;
  skill_vs_uniform: { log_loss_improvement: number; rps_improvement: number };
  dixon_coles: {
    rho: number;
    home_advantage: number;
    neutral_advantage: number;
    log_likelihood: number;
    converged: boolean;
    half_life_days: number;
  };
}

export interface FeatureWeight {
  feature: string;
  home_win: number;
  draw: number;
  away_win: number;
  abs_mean: number;
}

export interface Fixture {
  fixture_id: number;
  date: string;
  kickoff_et: string;
  group: string;
  home_team: string;
  away_team: string;
  venue: string;
  city: string;
  source: string;
}

export interface ApiErrorBody {
  error: string;
  message: string;
  status: number;
  details?: Record<string, unknown>;
}
